# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Public component SDK; importing contracts never loads robot or model code."""

from roborsi.contracts.component import (
    COMPONENT_API_VERSION,
    Capability,
    ComponentDescriptor,
    ComponentPlan,
    ComponentProvider,
    ComponentSpec,
    DependencyPort,
    FileIdentity,
    PreparedComponent,
    ResourceRequirements,
)
from roborsi.contracts.errors import ComponentError
from roborsi.contracts.lifecycle import ComponentContext, ComponentHandle

__all__ = [
    "COMPONENT_API_VERSION",
    "Capability",
    "ComponentContext",
    "ComponentDescriptor",
    "ComponentError",
    "ComponentHandle",
    "ComponentPlan",
    "ComponentProvider",
    "ComponentSpec",
    "DependencyPort",
    "FileIdentity",
    "PreparedComponent",
    "ResourceRequirements",
]
