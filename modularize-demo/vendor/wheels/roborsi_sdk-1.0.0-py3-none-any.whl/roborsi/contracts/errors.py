# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Machine-readable failures shared by providers and component consumers."""


class ComponentError(RuntimeError):
    """Report an operation failure without embedding credentials or configuration."""

    def __init__(self, code: str, message: str, *, component_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.component_id = component_id

    def as_dict(self) -> dict:
        """Return the portable error boundary used by the component CLI."""
        return {
            "code": self.code,
            "message": str(self),
            "component_id": self.component_id,
        }
