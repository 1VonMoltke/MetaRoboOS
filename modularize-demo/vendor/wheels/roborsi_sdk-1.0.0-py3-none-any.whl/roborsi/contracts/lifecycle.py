# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Explicit per-component resources, cancellation and ownership-aware cleanup."""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from threading import Event, RLock
from types import MappingProxyType
from typing import Any

from roborsi.contracts.errors import ComponentError


class ComponentHandle:
    """Own one local object or attachment; close its registered cleanup once.

    For remote attachments, cleanup must detach the client, not stop the remote
    service. ``owned`` records this distinction; it never implies remote control.
    """

    def __init__(
        self,
        component_id: str,
        value: Any,
        *,
        owned: bool = True,
        cleanup: Callable[[], None] | None = None,
    ):
        self.component_id = component_id
        self.owned = owned
        self._value = value
        self._cleanup = cleanup
        self._closed = False
        self._lock = RLock()

    @property
    def value(self) -> Any:
        """Access the live business interface, rejecting use after close."""
        if self._closed:
            raise ComponentError(
                "closed", "Component handle is closed", component_id=self.component_id
            )
        return self._value

    @property
    def closed(self) -> bool:
        return self._closed

    def close(self) -> None:
        """Attempt cleanup exactly once, including when cleanup itself fails."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            if self._cleanup is not None:
                self._cleanup()

    def __enter__(self) -> ComponentHandle:
        self.value
        return self

    def __exit__(self, *exc) -> None:
        self.close()


@dataclass(frozen=True)
class ComponentContext:
    """Runtime dependencies supplied explicitly; planning does not create paths."""

    workspace: Path
    root: Path = field(default_factory=Path.cwd)
    bindings: Mapping[str, ComponentHandle] = field(default_factory=dict)
    cancelled: Event | None = None
    deadline: float | None = None
    secret_resolver: Callable[[str], str] | None = field(default=None, repr=False)
    event_sink: Callable[[dict], None] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "root", Path(self.root).resolve())
        object.__setattr__(self, "workspace", Path(self.workspace).resolve())
        object.__setattr__(self, "bindings", MappingProxyType(dict(self.bindings)))

    def check(self) -> None:
        """Reject new work after cancellation or a monotonic deadline."""
        if self.cancelled is not None and self.cancelled.is_set():
            raise ComponentError("cancelled", "Component operation was cancelled")
        if self.deadline is not None and time.monotonic() >= self.deadline:
            raise ComponentError(
                "deadline_exceeded", "Component operation deadline exceeded"
            )

    def resolve(self, path: str | Path) -> Path:
        return (self.root / path).resolve()

    def ensure_workspace(self) -> Path:
        self.check()
        self.workspace.mkdir(parents=True, exist_ok=True)
        return self.workspace

    def binding(self, name: str) -> ComponentHandle:
        """Require an explicitly supplied live dependency."""
        self.check()
        try:
            handle = self.bindings[name]
        except KeyError:
            raise ComponentError(
                "missing_binding", f"Required component binding is missing: {name}"
            ) from None
        handle.value
        return handle

    def emit(self, component_id: str, stage: str) -> None:
        """Publish only operation identity, never full config or secret values."""
        if self.event_sink is not None:
            self.event_sink({"component_id": component_id, "stage": stage})
