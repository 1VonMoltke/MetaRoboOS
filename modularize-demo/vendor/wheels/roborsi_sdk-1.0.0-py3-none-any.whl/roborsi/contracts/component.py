# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Versioned descriptors and immutable, content-pinned component plans."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Protocol

from packaging.version import InvalidVersion, Version
from pydantic import BaseModel, ConfigDict, Field, field_validator

from roborsi.contracts._json import freeze
from roborsi.contracts.errors import ComponentError
from roborsi.contracts.lifecycle import ComponentContext, ComponentHandle
from roborsi.contracts._config import json_value, reject_secrets

COMPONENT_API_VERSION = "roborsi.component/v1"
COMPONENT_ID_PATTERN = r"^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$"
ComponentKind = Literal[
    "agent",
    "environment",
    "context",
    "model",
    "skill",
    "tool",
    "perception",
    "embodiment",
    "evaluation",
]


def canonical(value: Any) -> str:
    """Return deterministic finite JSON without implicit type conversion."""
    return json_value(value)


class Contract(BaseModel):
    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, validate_default=True
    )


class Capability(Contract):
    """Version a semantic capability; attributes hold units, frames and constraints."""

    contract: str = Field(pattern=r"^[a-z][a-z0-9_.-]*/v[1-9][0-9]*$")
    attributes: dict[str, Any] = Field(default_factory=dict)

    @field_validator("attributes")
    @classmethod
    def finite_attributes(cls, value):
        return freeze(json.loads(canonical(value)))


class DependencyPort(Contract):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]*$")
    capability: Capability
    optional: bool = False


class ResourceRequirements(Contract):
    """Declared requirements, not a claim of resource allocation or availability."""

    cpus: float = Field(default=1.0, gt=0, allow_inf_nan=False)
    memory_mb: int = Field(default=0, ge=0)
    gpus: int = Field(default=0, ge=0)
    devices: tuple[str, ...] = ()


class ComponentDescriptor(Contract):
    """Portable public metadata; business implementations are loaded separately."""

    schema_version: Literal[1] = 1
    api_version: Literal["roborsi.component/v1"] = COMPONENT_API_VERSION
    id: str = Field(pattern=COMPONENT_ID_PATTERN)
    kind: ComponentKind
    version: str
    description: str = ""
    config_schema: dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "additionalProperties": False}
    )
    requires: tuple[Capability, ...] = ()
    provides: tuple[Capability, ...] = ()
    dependencies: tuple[DependencyPort, ...] = ()
    resources: ResourceRequirements = Field(default_factory=ResourceRequirements)
    execution_modes: tuple[Literal["local", "docker", "http"], ...] = ("local",)

    @field_validator("version")
    @classmethod
    def valid_version(cls, value):
        try:
            Version(value)
        except InvalidVersion:
            raise ValueError("component version must be a PEP 440 version") from None
        return value

    @field_validator("config_schema")
    @classmethod
    def valid_schema(cls, value):
        from jsonschema import Draft202012Validator
        from jsonschema.exceptions import SchemaError

        value = json.loads(canonical(value))
        try:
            Draft202012Validator.check_schema(value)
        except SchemaError:
            raise ValueError(
                "component config_schema must be valid JSON Schema"
            ) from None
        if value.get("type") != "object":
            raise ValueError("component config_schema must describe an object")
        return freeze(value)


class ComponentSpec(Contract):
    """One provider request; graph composition is deliberately a later layer."""

    schema_version: Literal[1] = 1
    component: str = Field(pattern=COMPONENT_ID_PATTERN)
    version: str = ""
    config: dict[str, Any] = Field(default_factory=dict)

    @field_validator("config")
    @classmethod
    def safe_config(cls, value):
        reject_secrets(value)
        return freeze(json.loads(canonical(value)))


class FileIdentity(Contract):
    """A local file used by a plan, with its observed SHA-256 identity."""

    path: str
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")

    @classmethod
    def capture(cls, path: str | Path) -> FileIdentity:
        selected = Path(path).resolve()
        return cls(
            path=str(selected), sha256=hashlib.sha256(selected.read_bytes()).hexdigest()
        )

    def verify(self) -> None:
        try:
            actual = hashlib.sha256(Path(self.path).read_bytes()).hexdigest()
        except OSError:
            raise ComponentError(
                "input_changed", f"Planned input is missing: {self.path}"
            ) from None
        if actual != self.sha256:
            raise ComponentError(
                "input_changed", f"Planned input has changed: {self.path}"
            )


class ComponentPlan(Contract):
    """Snapshot config as canonical JSON, keeping runtime state out of plans."""

    schema_version: Literal[1] = 1
    descriptor: ComponentDescriptor
    configuration_json: str
    inputs: tuple[FileIdentity, ...] = ()
    metadata_json: str = "{}"

    @field_validator("configuration_json", "metadata_json")
    @classmethod
    def canonical_object(cls, value):
        document = json.loads(value)
        if not isinstance(document, dict):
            raise ValueError("plan config and metadata must be JSON objects")
        reject_secrets(document)
        return canonical(document)

    @property
    def config(self) -> dict:
        return json.loads(self.configuration_json)

    @property
    def metadata(self) -> dict:
        return json.loads(self.metadata_json)

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(
            canonical(self.model_dump(mode="json")).encode()
        ).hexdigest()

    def verify_inputs(self) -> None:
        for item in self.inputs:
            item.verify()


@dataclass(frozen=True)
class PreparedComponent:
    """Prepared state is process-local; only its plan is serializable."""

    plan: ComponentPlan
    state: Any = None


class ComponentProvider(Protocol):
    """Four stable SDK operations; handles expose kind-specific business APIs."""

    def describe(self) -> ComponentDescriptor: ...
    def plan(self, spec: ComponentSpec, context: ComponentContext) -> ComponentPlan: ...
    def prepare(
        self, plan: ComponentPlan, context: ComponentContext
    ) -> PreparedComponent: ...
    def open(
        self, prepared: PreparedComponent, context: ComponentContext
    ) -> ComponentHandle: ...
