# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Versioned business ports and executable episode semantics.

Lifecycle providers all use the same SDK. Their live values deliberately expose
different business APIs. Native environments retain stopping and score authority.
"""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

from pydantic import Field, field_validator, model_validator

from roborsi.contracts.component import Capability, Contract, canonical
from roborsi.contracts.errors import ComponentError


class ActionSpace(Contract):
    representation: str = Field(min_length=1)
    dimensions: int = Field(gt=0)
    units: tuple[str, ...]
    frame: str = Field(min_length=1)
    joint_names: tuple[str, ...] = ()
    gripper: str = "none"

    @model_validator(mode="after")
    def layout(self):
        if len(self.units) != self.dimensions:
            raise ValueError("action units must name every ordered dimension")
        if self.joint_names and len(self.joint_names) != self.dimensions:
            raise ValueError("joint_names must name every ordered dimension")
        if self.joint_names and len(set(self.joint_names)) != self.dimensions:
            raise ValueError("joint_names must be unique")
        return self


class EpisodeContract(Contract):
    api: Literal["roborsi.episode/v1"] = "roborsi.episode/v1"
    action_space: ActionSpace
    action_schema: dict[str, Any]
    observations: dict[str, Any]
    media: Literal["none", "shared_filesystem"] = "none"
    control_hz: float | None = Field(default=None, gt=0, allow_inf_nan=False)
    timestamp: str = "episode_step"
    stop_owner: Literal["environment"] = "environment"
    score_owner: Literal["environment"] = "environment"

    @field_validator("action_schema", "observations")
    @classmethod
    def valid_json(cls, value):
        import json

        from roborsi.contracts._json import freeze

        return freeze(json.loads(canonical(value)))

    @field_validator("action_schema")
    @classmethod
    def valid_action_schema(cls, value):
        from jsonschema import Draft202012Validator
        from jsonschema.exceptions import SchemaError

        try:
            Draft202012Validator.check_schema(value)
        except SchemaError:
            raise ValueError("action_schema must be valid JSON Schema") from None
        return value


def semantic_json(value):
    """Remove only non-operative JSON Schema documentation annotations."""
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if key in {"title", "description", "examples", "$comment"}:
                continue
            if key in {
                "properties",
                "patternProperties",
                "$defs",
                "definitions",
                "dependentSchemas",
            }:
                result[key] = {
                    name: semantic_json(schema) for name, schema in item.items()
                }
            elif key in {"allOf", "anyOf", "oneOf", "prefixItems"}:
                result[key] = [semantic_json(schema) for schema in item]
            elif key in {
                "items",
                "additionalProperties",
                "unevaluatedProperties",
                "unevaluatedItems",
                "contains",
                "propertyNames",
                "not",
                "if",
                "then",
                "else",
            }:
                result[key] = semantic_json(item)
            else:
                result[key] = item
        return result
    return value


def require_capability(
    required: Capability, provided: Capability, *, location="binding"
):
    """Match a versioned contract and recursively required semantic attributes.

    Object attributes are requirements/subsets; arrays are ordered and exact.
    Transformations must be explicit components, never implicit unit conversions.
    """
    if required.contract != provided.contract:
        raise ComponentError(
            "incompatible_contract", f"{location}: contract version differs"
        )

    def check(left, right, path):
        if isinstance(left, dict):
            if not isinstance(right, dict):
                raise ComponentError(
                    "incompatible_contract", f"{path}: expected an object"
                )
            for name, item in left.items():
                if name not in right:
                    raise ComponentError(
                        "incompatible_contract",
                        f"{path}.{name}: required attribute missing",
                    )
                check(item, right[name], path + "." + name)
        elif left != right or type(left) is not type(right):
            raise ComponentError(
                "incompatible_contract", f"{path}: semantic value differs"
            )

    check(required.attributes, provided.attributes, location)


def require_episode(
    required: EpisodeContract, provided: EpisodeContract, *, location="episode"
):
    left, right = required.model_dump(mode="json"), provided.model_dump(mode="json")
    # Schema restrictions are exact: subset comparison would silently accept a
    # provider adding constraints that invalidate the Agent's legal actions.
    if semantic_json(left.pop("action_schema")) != semantic_json(
        right.pop("action_schema")
    ):
        raise ComponentError(
            "incompatible_contract", f"{location}: action_schema differs"
        )
    require_capability(
        Capability(contract=required.api, attributes=left),
        Capability(contract=provided.api, attributes=right),
        location=location,
    )


@runtime_checkable
class AgentAPI(Protocol):
    def reset(self, task: Any) -> None: ...
    def act(self, observation: Any) -> Any: ...
    def close(self) -> None: ...


@runtime_checkable
class EnvironmentAPI(Protocol):
    name: str

    def tasks(self) -> list: ...
    def runtime_info(self) -> Any: ...
    def assets(self) -> list: ...
    def create_adapter(self, directory: Path, artifacts: Any) -> Any: ...


@runtime_checkable
class ContextAPI(Protocol):
    def select(self, task_id: str) -> Any: ...


@runtime_checkable
class SealedContextAPI(ContextAPI, Protocol):
    map_path: Path
    package_root: Path
    packages: Mapping[str, Any]


@runtime_checkable
class ModelAPI(Protocol):
    def generate(self, request: dict) -> dict: ...


@runtime_checkable
class ToolAPI(Protocol):
    def invoke(self, request: dict) -> dict: ...


@runtime_checkable
class PerceptionAPI(Protocol):
    def infer(self, observation: dict, request: dict) -> dict: ...


@runtime_checkable
class SkillAPI(Protocol):
    def manifest(self) -> dict: ...


@runtime_checkable
class EmbodimentAPI(Protocol):
    def manifest(self) -> dict: ...


@runtime_checkable
class EvaluationAPI(Protocol):
    def aggregate(self, native_results: list[dict]) -> dict: ...


BUSINESS_APIS = {
    "agent": AgentAPI,
    "environment": EnvironmentAPI,
    "context": ContextAPI,
    "model": ModelAPI,
    "tool": ToolAPI,
    "perception": PerceptionAPI,
    "skill": SkillAPI,
    "embodiment": EmbodimentAPI,
    "evaluation": EvaluationAPI,
}


def validate_business(kind, value):
    methods = {
        "agent": ("reset", "act", "close"),
        "environment": ("tasks", "runtime_info", "assets", "create_adapter"),
        "context": ("select",),
        "model": ("generate",),
        "tool": ("invoke",),
        "perception": ("infer",),
        "skill": ("manifest",),
        "embodiment": ("manifest",),
        "evaluation": ("aggregate",),
    }
    if not isinstance(value, BUSINESS_APIS[kind]) or any(
        not callable(getattr(value, name, None)) for name in methods[kind]
    ):
        raise ComponentError(
            "invalid_business_api",
            f"Live component does not implement {kind}/v1 business methods",
        )
