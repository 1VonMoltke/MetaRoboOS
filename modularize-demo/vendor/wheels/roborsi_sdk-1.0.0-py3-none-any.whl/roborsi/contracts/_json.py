# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Read-only JSON containers for nested contract values."""


def _immutable(*args, **kwargs):
    raise TypeError("contract JSON values are immutable")


class _Object(dict):
    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = _immutable
    __ior__ = _immutable

    def __deepcopy__(self, memo):
        return self


class _Array(list):
    __setitem__ = __delitem__ = append = clear = extend = insert = pop = remove = (
        _immutable
    )
    reverse = sort = __iadd__ = __imul__ = _immutable

    def __deepcopy__(self, memo):
        return self


def freeze(value):
    """Preserve JSON/list/dict semantics while preventing in-place mutation."""
    if isinstance(value, dict):
        return _Object({key: freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return _Array(freeze(item) for item in value)
    return value
