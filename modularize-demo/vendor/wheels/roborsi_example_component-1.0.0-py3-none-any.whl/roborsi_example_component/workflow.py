# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""A complete external benchmark/policy/model/context with no core registrations."""

import hashlib
import json
import os
import time
from pathlib import Path

from roborsi.components.provider import BaseProvider
from roborsi.contracts import (
    Capability,
    ComponentDescriptor,
    ComponentHandle,
    DependencyPort,
    FileIdentity,
)
from roborsi.contracts.business import ActionSpace, EpisodeContract

ACTION = {
    "type": "object",
    "properties": {"increment": {"type": "integer", "minimum": 1, "maximum": 2}},
    "required": ["increment"],
    "additionalProperties": False,
}


def episode_contract():
    return EpisodeContract(
        action_space=ActionSpace(
            representation="counter_increment",
            dimensions=1,
            units=("count",),
            frame="counter",
        ),
        action_schema=ACTION,
        observations={"position": {"unit": "count", "frame": "counter"}},
        control_hz=1.0,
    ).model_dump(mode="json")


class CounterAdapter:
    def __init__(self, directory, config):
        self.directory = Path(directory)
        self.config = config
        self.closed = False
        self.steps = self.position = 0

    def _observation(self):
        from roborsi.evaluation.messages import Observation

        return Observation(
            benchmark=self.task.benchmark,
            episode_id=self.episode_id,
            step_index=self.steps,
            data={"position": self.position},
        )

    def start(self, task, episode_id):
        from roborsi.evaluation.messages import StartResult

        if self.config.get("fail_start"):
            raise RuntimeError("injected environment start failure")
        self.task, self.episode_id = task, episode_id
        self.target = task.native["goal"]
        return StartResult(
            task=task, observation=self._observation(), capabilities=task.capabilities
        )

    def step(self, action):
        from jsonschema import validate

        from roborsi.evaluation.messages import StepResult

        if self.config.get("disconnect"):
            os._exit(17)
        if self.config.get("step_delay_s"):
            time.sleep(self.config["step_delay_s"])
        if self.config.get("fail_step"):
            raise RuntimeError("injected environment step failure")
        validate(action.data, ACTION)
        self.position += action.data["increment"]
        self.steps += 1
        success = self.position >= self.target
        truncated = self.steps >= self.task.max_steps and not success
        return StepResult(
            observation=self._observation(),
            terminated=success,
            truncated=truncated,
            termination_reason="native_success"
            if success
            else "native_limit"
            if truncated
            else None,
            reward=float(success),
            native={"physical_steps": self.steps},
        )

    def finish(self):
        from roborsi.evaluation.messages import NativeResult
        from roborsi.evaluation.result import write_json_atomic

        path = self.directory / "native/score.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        details = {
            "position": self.position,
            "physical_steps": self.steps,
            "goal": self.target,
        }
        write_json_atomic(path, details)
        return NativeResult(
            task=self.task,
            episode_id=self.episode_id,
            success=self.position >= self.target,
            score=float(self.position >= self.target),
            details=details,
            source="native/score.json",
            source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        )

    def close(self):
        self.closed = True


class CounterBenchmark:
    def __init__(self, config):
        self.config = config
        self.name = config.get("benchmark", "example_counter")
        self.adapters = []

    def tasks(self):
        from roborsi.evaluation.messages import Task

        return [
            Task(
                benchmark=self.name,
                task_id=f"count-{goal}",
                seed=seed,
                instruction=f"Reach {goal}",
                max_steps=goal,
                native={"goal": goal},
                capabilities={"action_schema": ACTION},
            )
            for goal in self.config.get("goals", [2, 3])
            for seed in self.config.get("seeds", [0])
        ]

    def runtime_info(self):
        from roborsi.evaluation.messages import BenchmarkRuntimeInfo

        return BenchmarkRuntimeInfo(
            benchmark=self.name,
            benchmark_version="example-counter-v1",
            benchmark_commit="1" * 40,
            adapter_version="example-counter-adapter-v1",
            platform={"runtime": "python"},
            evaluation={
                "success_metric": "native_goal",
                "score_metric": "native_goal",
                "aggregation": "case_mean",
                "error_denominator": "expected",
            },
        )

    def assets(self):
        return []

    def create_adapter(self, directory, artifacts):
        adapter = CounterAdapter(directory, self.config)
        self.adapters.append(adapter)
        return adapter

    def close(self):
        for adapter in self.adapters:
            adapter.close()


class EnvironmentProvider(BaseProvider):
    descriptor = ComponentDescriptor(
        id="environment.example_workflow",
        kind="environment",
        version="1.0.0",
        execution_modes=("local", "docker", "http"),
        provides=(Capability(contract="environment.counter/v1"),),
        config_schema={
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "benchmark": {"type": "string", "minLength": 1},
                "goals": {
                    "type": "array",
                    "minItems": 1,
                    "uniqueItems": True,
                    "items": {"type": "integer", "minimum": 1},
                },
                "seeds": {
                    "type": "array",
                    "minItems": 1,
                    "uniqueItems": True,
                    "items": {"type": "integer", "minimum": 0},
                },
                "step_delay_s": {"type": "number", "minimum": 0},
                "fail_step": {"type": "boolean"},
                "fail_start": {"type": "boolean"},
                "fail_prepare": {"type": "boolean"},
                "prepare_delay_s": {"type": "number", "minimum": 0},
                "fail_open": {"type": "boolean"},
                "disconnect": {"type": "boolean"},
            },
        },
    )

    def plan(self, spec, context):
        return self.make_plan(
            spec, context, metadata={"episode_contract": episode_contract()}
        )

    def prepare(self, plan, context):
        if plan.config.get("prepare_delay_s"):
            time.sleep(plan.config["prepare_delay_s"])
        if plan.config.get("fail_prepare"):
            raise RuntimeError("injected prepare failure")
        return super().prepare(plan, context)

    def open(self, prepared, context):
        self.verify(prepared.plan, context)
        if prepared.plan.config.get("fail_open"):
            raise RuntimeError("injected open failure")
        benchmark = CounterBenchmark(prepared.plan.config)
        return ComponentHandle(self.descriptor.id, benchmark, cleanup=benchmark.close)


class CounterModel:
    def __init__(self, config):
        self.config = config

    def generate(self, request):
        if self.config.get("delay_s"):
            time.sleep(self.config["delay_s"])
        if self.config.get("fail"):
            raise RuntimeError("injected model failure")
        return {"increment": self.config.get("increment", 1)}


class ModelProvider(BaseProvider):
    descriptor = ComponentDescriptor(
        id="model.example_counter",
        kind="model",
        version="1.0.0",
        provides=(Capability(contract="model.counter_action/v1"),),
        config_schema={
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "increment": {"type": "integer", "minimum": 1, "maximum": 2},
                "delay_s": {"type": "number", "minimum": 0},
                "fail": {"type": "boolean"},
            },
        },
    )

    def plan(self, spec, context):
        return self.make_plan(spec, context)

    def open(self, prepared, context):
        self.verify(prepared.plan, context)
        return ComponentHandle(self.descriptor.id, CounterModel(prepared.plan.config))


class Memory:
    def __init__(self, text):
        self.text = text

    def select(self, task_id):
        return {"task_id": task_id, "memory": self.text}


class MemoryProvider(BaseProvider):
    descriptor = ComponentDescriptor(
        id="context.example_memory",
        kind="context",
        version="1.0.0",
        provides=(Capability(contract="context.counter_memory/v1"),),
        config_schema={
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "text": {"type": "string"},
                "file": {"type": "string", "minLength": 1},
            },
        },
    )

    def plan(self, spec, context):
        config, inputs = dict(spec.config), []
        if "file" in config:
            config["file"] = str(context.resolve(config["file"]))
            inputs.append(FileIdentity.capture(config["file"]))
        return self.make_plan(spec, context, config=config, inputs=inputs)

    def open(self, prepared, context):
        self.verify(prepared.plan, context)
        return ComponentHandle(
            self.descriptor.id,
            Memory(
                Path(prepared.plan.config["file"]).read_text()
                if "file" in prepared.plan.config
                else prepared.plan.config.get("text", "Count carefully")
            ),
        )


class CounterAgent:
    def __init__(self, model, memory):
        self.model, self.memory = model, memory
        self.closed = False

    def reset(self, task):
        self.task = task

    def act(self, observation):
        from roborsi.evaluation.messages import Action

        data = self.model.generate(
            {
                "observation": observation.data,
                "context": self.memory.select(self.task.task_id),
            }
        )
        return Action(
            benchmark=observation.benchmark,
            episode_id=observation.episode_id,
            step_index=observation.step_index,
            data=data,
        )

    def close(self):
        self.closed = True


class AgentProvider(BaseProvider):
    descriptor = ComponentDescriptor(
        id="agent.example_counter",
        kind="agent",
        version="1.0.0",
        execution_modes=("local", "docker", "http"),
        dependencies=(
            DependencyPort(
                name="model", capability=Capability(contract="model.counter_action/v1")
            ),
            DependencyPort(
                name="context",
                capability=Capability(contract="context.counter_memory/v1"),
            ),
        ),
        provides=(Capability(contract="agent.roborsi_episode/v1"),),
    )

    def plan(self, spec, context):
        return self.make_plan(
            spec, context, metadata={"episode_contract": episode_contract()}
        )

    def open(self, prepared, context):
        self.verify(prepared.plan, context)
        (context.ensure_workspace() / "agent_runtime.json").write_text(
            json.dumps(
                {
                    "workspace": str(context.workspace),
                    "media_dir": os.environ.get("ROBORSI_MEDIA_DIR"),
                    "setting": os.environ.get("ROBORSI_COMPONENT_TEST_SETTING"),
                }
            )
        )
        agent = CounterAgent(
            context.binding("model").value, context.binding("context").value
        )
        return ComponentHandle(self.descriptor.id, agent, cleanup=agent.close)


def environment_provider():
    return EnvironmentProvider()


def model_provider():
    return ModelProvider()


def context_provider():
    return MemoryProvider()


def agent_provider():
    return AgentProvider()
