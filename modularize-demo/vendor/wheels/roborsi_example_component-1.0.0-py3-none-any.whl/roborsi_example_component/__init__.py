# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Small deterministic environment, independent of the RoboRSI source checkout."""

from roborsi.components.provider import BaseProvider
from roborsi.contracts import Capability, ComponentDescriptor, ComponentHandle


class CounterEnvironment:
    """A tiny environment with a kind-specific business interface."""

    def __init__(self, goal):
        self.goal = goal
        self.position = 0
        self.closed = False

    def reset(self):
        if self.closed:
            raise RuntimeError("environment is closed")
        self.position = 0
        return {"position": self.position, "success": False}

    def step(self, increment):
        if self.closed:
            raise RuntimeError("environment is closed")
        if type(increment) is not int or increment < 1:
            raise ValueError("increment must be a positive integer")
        self.position += increment
        return {"position": self.position, "success": self.position >= self.goal}

    def close(self):
        self.closed = True


class CounterProvider(BaseProvider):
    descriptor = ComponentDescriptor(
        id="environment.example_counter",
        kind="environment",
        version="1.0.0",
        config_schema={
            "type": "object",
            "additionalProperties": False,
            "properties": {"goal": {"type": "integer", "minimum": 1}},
            "required": ["goal"],
        },
        provides=(Capability(contract="environment.example_counter/v1"),),
    )

    def plan(self, spec, context):
        return self.make_plan(spec, context)

    def open(self, prepared, context):
        self.verify(prepared.plan, context)
        value = CounterEnvironment(prepared.plan.config["goal"])
        return ComponentHandle(self.descriptor.id, value, cleanup=value.close)


def provider():
    return CounterProvider()
