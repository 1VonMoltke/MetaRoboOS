# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Inspect registered components and plan one provider without starting services."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from roborsi.components import default_registry
from roborsi.contracts import ComponentContext, ComponentError, ComponentSpec


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--no-discover", action="store_true", help="use source built-ins only"
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="list names without loading implementations")
    describe = commands.add_parser(
        "describe", help="show descriptor and config JSON Schema"
    )
    describe.add_argument("component")
    plan = commands.add_parser(
        "plan", help="read local inputs only; no downloads or services"
    )
    plan.add_argument("spec", type=Path)
    plan.add_argument(
        "--root", type=Path, default=Path.cwd(), help="base for paths inside config"
    )
    plan.add_argument("--workspace", type=Path, default=Path("work/components"))
    args = parser.parse_args(argv)
    try:
        registry = default_registry(discover=not args.no_discover)
        if args.command == "list":
            document = registry.entries()
        elif args.command == "describe":
            document = registry.describe(args.component).model_dump(mode="json")
        else:
            spec = ComponentSpec.model_validate_json(
                json.dumps(yaml.safe_load(args.spec.read_text()))
            )
            context = ComponentContext(root=args.root, workspace=args.workspace)
            result = registry.plan(spec, context)
            document = {
                "plan": result.model_dump(mode="json"),
                "fingerprint": result.fingerprint,
            }
        print(json.dumps(document, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except ComponentError as exc:
        print(json.dumps({"error": exc.as_dict()}))
        return 2
    except (ValueError, OSError, yaml.YAMLError):
        # ValidationError may include the raw input; do not echo it or secrets.
        print(
            json.dumps({
                "error": {
                    "code": "invalid_request",
                    "message": "Invalid component request or local input; check paths and descriptor schema.",
                }
            })
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
