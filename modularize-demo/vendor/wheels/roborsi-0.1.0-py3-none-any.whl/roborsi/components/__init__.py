# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Component discovery and explicit lifecycle operations, independent of backends."""

from roborsi.components.registry import ComponentRegistry, default_registry

__all__ = ["ComponentRegistry", "default_registry"]
