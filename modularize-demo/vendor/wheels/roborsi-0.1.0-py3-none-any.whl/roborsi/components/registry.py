# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Lazy entry-point discovery, explicit version selection and lifecycle checks."""

from __future__ import annotations

import re
from importlib import metadata

from packaging.specifiers import InvalidSpecifier, SpecifierSet

from roborsi.contracts import (
    ComponentDescriptor,
    ComponentError,
    ComponentHandle,
    ComponentPlan,
    PreparedComponent,
)
from roborsi.contracts.component import COMPONENT_ID_PATTERN

ENTRY_POINT_GROUP = "roborsi.components"



class ComponentRegistry:
    """Discover trusted installed plugins without importing their implementation.

    Registering entry points does not execute them. ``provider``/``describe``
    loads only the requested factory. Discovery is not a sandbox for plugin code.
    """

    def __init__(self):
        self._factories = {}
        self._providers = {}
        self._origins = {}

    def register_factory(self, component_id, factory, *, origin="explicit"):
        if (
            not isinstance(component_id, str)
            or re.fullmatch(COMPONENT_ID_PATTERN, component_id) is None
        ):
            raise ComponentError(
                "invalid_plugin", "Component id must be a lowercase dotted name"
            )
        if component_id in self._factories:
            raise ComponentError(
                "duplicate_component",
                f"Component is already registered: {component_id}",
            )
        if not callable(factory):
            raise ComponentError("invalid_plugin", "Component factory must be callable")
        self._factories[component_id] = factory
        self._origins[component_id] = origin

    def register(self, provider):
        descriptor = self._descriptor(provider)
        self.register_factory(descriptor.id, lambda: provider)

    @staticmethod
    def _descriptor(provider):
        for name in ("describe", "plan", "prepare", "open"):
            if not callable(getattr(provider, name, None)):
                raise ComponentError(
                    "invalid_plugin", f"Provider must implement {name}"
                )
        descriptor = provider.describe()
        if not isinstance(descriptor, ComponentDescriptor):
            raise ComponentError(
                "invalid_plugin", "describe() must return ComponentDescriptor"
            )
        try:
            return ComponentDescriptor.model_validate_json(descriptor.model_dump_json())
        except ValueError as exc:
            raise ComponentError(
                "invalid_plugin",
                "Provider descriptor does not implement the supported API",
            ) from exc

    def discover(self, *, entry_points=None):
        entries = (
            metadata.entry_points(group=ENTRY_POINT_GROUP)
            if entry_points is None
            else entry_points
        )
        staged = []
        seen = set(self._factories)
        for entry in sorted(entries, key=lambda item: (item.name, item.value)):
            if entry.group != ENTRY_POINT_GROUP:
                continue
            if re.fullmatch(COMPONENT_ID_PATTERN, entry.name) is None:
                raise ComponentError(
                    "invalid_plugin",
                    "Entry-point name must be a lowercase dotted component id",
                )
            if entry.name in seen:
                raise ComponentError(
                    "duplicate_component", f"Conflicting entry point: {entry.name}"
                )
            seen.add(entry.name)
            dist = getattr(entry, "dist", None)
            owner = dist.metadata.get("Name", "") if dist is not None else ""
            staged.append((entry, owner))
        for entry, owner in staged:
            self.register_factory(
                entry.name, lambda ep=entry: ep.load()(), origin=owner or "entry_point"
            )
        return self

    def entries(self):
        return [
            {
                "id": name,
                "origin": self._origins[name],
                "loaded": name in self._providers,
            }
            for name in sorted(self._factories)
        ]

    def provider(self, component_id, *, version=""):
        try:
            requirement = SpecifierSet(version)
        except InvalidSpecifier:
            raise ComponentError(
                "invalid_version", "Invalid component version constraint"
            ) from None
        if component_id not in self._factories:
            raise ComponentError(
                "component_not_found", f"Component is not registered: {component_id}"
            )
        if component_id not in self._providers:
            try:
                provider = self._factories[component_id]()
            except Exception as exc:
                raise ComponentError(
                    "plugin_load_failed",
                    "Component factory failed to load",
                    component_id=component_id,
                ) from exc
            descriptor = self._descriptor(provider)
            if descriptor.id != component_id:
                raise ComponentError(
                    "provider_mismatch", "Entry-point name differs from descriptor id"
                )
            self._providers[component_id] = provider
        provider = self._providers[component_id]
        descriptor = self._descriptor(provider)
        if not requirement.contains(descriptor.version, prereleases=True):
            raise ComponentError(
                "incompatible_version",
                f"No compatible version registered for {component_id}",
            )
        return provider

    def describe(self, component_id):
        return self._descriptor(self.provider(component_id))

    def plan(self, spec, context):
        context.check()
        context.emit(spec.component, "plan")
        provider = self.provider(spec.component, version=spec.version)
        plan = provider.plan(spec, context)
        if not isinstance(plan, ComponentPlan):
            raise ComponentError("invalid_plugin", "plan() must return ComponentPlan")
        if plan.descriptor != self._descriptor(provider):
            raise ComponentError(
                "provider_mismatch", "Provider returned a different plan descriptor"
            )
        return plan

    def prepare(self, plan, context):
        context.check()
        context.emit(plan.descriptor.id, "prepare")
        provider = self.provider(
            plan.descriptor.id, version="==" + plan.descriptor.version
        )
        if plan.descriptor != self._descriptor(provider):
            raise ComponentError("provider_mismatch", "Plan descriptor has changed")
        plan.verify_inputs()
        prepared = provider.prepare(plan, context)
        if not isinstance(prepared, PreparedComponent):
            raise ComponentError(
                "invalid_plugin", "prepare() must return PreparedComponent"
            )
        if prepared.plan != plan:
            raise ComponentError(
                "provider_mismatch", "Provider prepared a different plan"
            )
        return prepared

    def open(self, prepared, context):
        plan = prepared.plan
        context.check()
        context.emit(plan.descriptor.id, "open")
        provider = self.provider(
            plan.descriptor.id, version="==" + plan.descriptor.version
        )
        if plan.descriptor != self._descriptor(provider):
            raise ComponentError("provider_mismatch", "Plan descriptor has changed")
        plan.verify_inputs()
        handle = provider.open(prepared, context)
        if not isinstance(handle, ComponentHandle):
            raise ComponentError(
                "invalid_plugin", "Provider must return a ComponentHandle"
            )
        if handle.component_id != plan.descriptor.id:
            handle.close()
            raise ComponentError(
                "provider_mismatch", "Provider opened another component"
            )
        return handle


def default_registry(*, discover=True):
    """Discover only installed plugins; core has no concrete plugin fallback."""
    registry = ComponentRegistry()
    if discover:
        registry.discover()
    return registry
