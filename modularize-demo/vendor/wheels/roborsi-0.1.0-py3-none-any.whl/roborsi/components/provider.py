# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Reusable provider validation with no robot, model or subprocess dependencies."""

from roborsi.contracts import ComponentError, ComponentPlan, PreparedComponent
from roborsi.contracts.component import canonical


class BaseProvider:
    """Implement the common contract while leaving business APIs to providers."""

    descriptor = None

    def describe(self):
        return self.descriptor.model_copy(deep=True)

    def validate(self, spec, context):
        from jsonschema import Draft202012Validator

        context.check()
        if spec.component != self.descriptor.id:
            raise ComponentError("provider_mismatch", "Spec selects another provider")
        errors = list(
            Draft202012Validator(self.descriptor.config_schema).iter_errors(spec.config)
        )
        if errors:
            paths = [
                ".".join(str(p) for p in error.absolute_path) or "config"
                for error in errors
            ]
            raise ComponentError(
                "invalid_config",
                "Invalid component configuration at: " + ", ".join(paths),
                component_id=spec.component,
            )

    def make_plan(self, spec, context, *, config=None, inputs=(), metadata=None):
        self.validate(spec, context)
        return ComponentPlan(
            descriptor=self.describe(),
            configuration_json=canonical(spec.config if config is None else config),
            inputs=tuple(inputs),
            metadata_json=canonical(metadata or {}),
        )

    def verify(self, plan, context):
        context.check()
        if plan.descriptor != self.describe():
            raise ComponentError(
                "provider_mismatch", "Plan descriptor does not match the provider"
            )
        plan.verify_inputs()

    def prepare(self, plan, context):
        self.verify(plan, context)
        return PreparedComponent(plan)
