# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Logical assemblies are separate from task selection and deployment settings."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from pydantic import Field, field_validator, model_validator

from roborsi.contracts import ComponentSpec, ResourceRequirements
from roborsi.contracts._json import freeze
from roborsi.contracts.component import Contract

NAME = r"^[a-z][a-z0-9_]*$"


class ComponentNode(ComponentSpec):
    bindings: dict[str, str] = Field(default_factory=dict)

    @field_validator("bindings")
    @classmethod
    def immutable(cls, value):
        return freeze(value)


class Entrypoints(Contract):
    agent: str = Field(pattern=NAME)
    environment: str = Field(pattern=NAME)


class AssemblySpec(Contract):
    schema_version: Literal[1] = 1
    components: dict[str, ComponentNode]
    entrypoints: Entrypoints

    @field_validator("components")
    @classmethod
    def immutable(cls, value):
        return freeze(value)

    @model_validator(mode="after")
    def names(self):
        import re

        if not self.components or any(
            not re.fullmatch(NAME, name) for name in self.components
        ):
            raise ValueError("component aliases must be nonempty lowercase names")
        if any(
            not re.fullmatch(NAME, port)
            for node in self.components.values()
            for port in node.bindings
        ):
            raise ValueError("binding port names must be lowercase names")
        if self.entrypoints.agent == self.entrypoints.environment:
            raise ValueError("agent and environment entrypoints must differ")
        return self


class Mount(Contract):
    source: str
    target: str
    readonly: bool = True

    @model_validator(mode="after")
    def paths(self):
        if (
            not Path(self.target).is_absolute()
            or "," in self.target
            or "," in self.source
        ):
            raise ValueError(
                "mount target must be absolute and mount paths cannot contain commas"
            )
        return self


class Deployment(Contract):
    backend: Literal["local", "docker", "http"] = "local"
    python: str | None = None
    image: str | None = None
    endpoint: str | None = None
    media_root: str | None = None
    credential_env: tuple[str, ...] = ()
    environment: dict[str, str] = Field(default_factory=dict)
    mounts: tuple[Mount, ...] = ()
    startup_timeout_s: float = Field(default=30.0, gt=0, allow_inf_nan=False)
    resources: ResourceRequirements | None = None

    @field_validator("environment")
    @classmethod
    def explicit_settings(cls, value):
        import re

        from roborsi.utils.config_values import reject_secrets

        reject_secrets(value)
        if any(
            re.search(r"(^|_)(KEY|TOKEN|PASSWORD|SECRET|CREDENTIAL)(_|$)", key, re.I)
            for key in value
        ):
            raise ValueError("secret settings must use credential_env references")
        if any(
            not key or "=" in key or "\x00" in key or "\x00" in item
            for key, item in value.items()
        ):
            raise ValueError("invalid explicit process setting")
        return freeze(value)

    @field_validator("credential_env")
    @classmethod
    def names(cls, value):
        import re

        if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) for name in value):
            raise ValueError("credential_env must contain environment variable names")
        return value

    @model_validator(mode="after")
    def configuration(self):
        if self.backend == "docker":
            import re

            if (
                not self.image
                or re.fullmatch(r"(?:[^\s]+@)?sha256:[0-9a-f]{64}", self.image) is None
            ):
                raise ValueError(
                    "Docker deployment requires an immutable image digest or local sha256 image id"
                )
            if self.endpoint or self.python:
                raise ValueError(
                    "Docker cannot use a Python executable or attachment endpoint"
                )
        elif self.image or self.mounts:
            raise ValueError("image and mounts apply only to Docker")
        if self.backend == "http":
            if self.media_root and not Path(self.media_root).is_absolute():
                raise ValueError(
                    "attachment media_root must be an absolute shared-filesystem root"
                )
            parsed = urlsplit(self.endpoint or "")
            try:
                valid = parsed.port != 0
            except ValueError:
                valid = False
            if (
                not valid
                or parsed.scheme not in {"http", "https"}
                or not parsed.hostname
                or parsed.username
                or parsed.password
                or parsed.query
                or parsed.fragment
                or parsed.path not in {"", "/"}
            ):
                raise ValueError(
                    "HTTP attachment requires an origin URL without credentials"
                )
            if self.environment or self.credential_env or self.python or self.resources:
                raise ValueError(
                    "HTTP attachments cannot configure or reserve remote process resources"
                )
        elif self.endpoint:
            raise ValueError("endpoint applies only to HTTP attachments")
        elif self.media_root:
            raise ValueError("media_root applies only to HTTP attachments")
        return self


class Inventory(Contract):
    cpus: float = Field(default=0.0, ge=0, allow_inf_nan=False)
    memory_mb: int = Field(default=0, ge=0)
    gpus: tuple[str, ...] = ()
    devices: tuple[str, ...] = ()


class RunSpec(Contract):
    schema_version: Literal[1] = 1
    run_id: str = Field(pattern=r"^[A-Za-z0-9_-]+$")
    results_root: str = "work/assembly-results"
    workspace: str = "work/assembly-runtime"
    tasks: tuple[str, ...] = ()
    seeds: tuple[int, ...] = ()
    max_concurrent: int = Field(default=1, gt=0)
    timeout_s: float = Field(default=30.0, gt=0, allow_inf_nan=False)
    case_timeout_s: float = Field(default=3600.0, gt=0, allow_inf_nan=False)
    deployments: dict[str, Deployment] = Field(default_factory=dict)
    inventory: Inventory = Field(default_factory=Inventory)
    lease_root: str = "work/component-leases"
    lease_timeout_s: float = Field(default=30.0, gt=0, allow_inf_nan=False)
    resume_from: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]+$")

    @field_validator("deployments")
    @classmethod
    def immutable(cls, value):
        return freeze(value)

    @model_validator(mode="after")
    def selection(self):
        if any(seed < 0 for seed in self.seeds) or len(set(self.seeds)) != len(
            self.seeds
        ):
            raise ValueError("seeds must be unique nonnegative integers")
        if len(set(self.tasks)) != len(self.tasks):
            raise ValueError("tasks must be unique")
        return self


def load_spec(path, model):
    import yaml

    return model.model_validate_json(json.dumps(yaml.safe_load(Path(path).read_text())))
