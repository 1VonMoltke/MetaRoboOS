# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
from roborsi.assembly.cli import main

raise SystemExit(main())
