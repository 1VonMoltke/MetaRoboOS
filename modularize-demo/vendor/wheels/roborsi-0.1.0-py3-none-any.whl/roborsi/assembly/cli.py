# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Validate, lock or run a declarative assembly of installed component plugins."""

from __future__ import annotations

import argparse
import json
import signal
import sys
from pathlib import Path
from threading import Event

from roborsi.assembly.resolver import resolve
from roborsi.assembly.spec import AssemblySpec, RunSpec, load_spec
from roborsi.components import default_registry
from roborsi.contracts import ComponentContext


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assembly", type=Path, required=True)
    parser.add_argument(
        "--run-spec",
        type=Path,
        help="separate task/deployment RunSpec; required to execute",
    )
    parser.add_argument(
        "--root", type=Path, default=Path.cwd(), help="root for declared resource paths"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="resolve contracts without preparing or allocating",
    )
    parser.add_argument("--lock", type=Path, help="write the resolved content lock")
    parser.add_argument(
        "--expect-lock",
        type=Path,
        help="reject drift against a previously reviewed lock",
    )
    parser.add_argument("--progress", action="store_true")
    args = parser.parse_args(argv)
    try:
        spec = load_spec(args.assembly, AssemblySpec)
        run = load_spec(args.run_spec, RunSpec) if args.run_spec else None
        resolved = resolve(
            spec, ComponentContext(args.root / ".assembly-plan", root=args.root)
        )
        if (
            args.expect_lock
            and json.loads(args.expect_lock.read_text()) != resolved.lock
        ):
            raise ValueError("resolved assembly differs from --expect-lock")
        if args.lock:
            args.lock.parent.mkdir(parents=True, exist_ok=True)
            args.lock.write_text(json.dumps(resolved.lock, indent=2) + "\n")
        if args.dry_run:
            if run:
                from roborsi.execution.runtime import RuntimeSupervisor

                RuntimeSupervisor(
                    resolved,
                    run,
                    args.root / run.workspace / run.run_id,
                    default_registry(),
                )
            print(
                json.dumps(
                    {
                        "fingerprint": resolved.fingerprint,
                        "order": resolved.order,
                        "bindings": {
                            name: dict(value)
                            for name, value in resolved.bindings.items()
                        },
                        "lock": resolved.lock,
                    },
                    indent=2,
                )
            )
            return 0
        if run is None:
            parser.error("--run-spec is required unless --dry-run is supplied")
        from roborsi.evaluation.component_workflow import run_assembly

        cancel = Event()
        previous = {}
        for signum in (signal.SIGTERM, signal.SIGINT):
            previous[signum] = signal.signal(signum, lambda *args: cancel.set())
        try:
            report = run_assembly(
                spec,
                run,
                root=args.root,
                cancel_event=cancel,
                expected_lock=resolved.lock,
                progress=(
                    lambda event: print(json.dumps(event), file=sys.stderr, flush=True)
                )
                if args.progress
                else None,
            )
        finally:
            for signum, handler in previous.items():
                signal.signal(signum, handler)
        print(json.dumps(report.as_dict(), indent=2))
        return (
            0
            if all(
                case.result.status in {"success", "task_failure"}
                for case in report.cases
            )
            else 1
        )
    except (ValueError, OSError, RuntimeError) as exc:
        print(f"assembly: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
