# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Validate semantic graphs and produce content-addressed relocatable locks."""

from __future__ import annotations

import hashlib
import inspect
import json
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass, replace
from pathlib import Path
from types import MappingProxyType

from roborsi.assembly.spec import AssemblySpec
from roborsi.components import default_registry
from roborsi.contracts import ComponentContext, ComponentError, ComponentSpec
from roborsi.contracts.business import (
    EpisodeContract,
    require_capability,
    require_episode,
    validate_business,
)
from roborsi.contracts.component import canonical


def _hash(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def core_identity():
    """Pin shipped Python modules and wire schemas, not installation locators."""
    package = Path(__file__).resolve().parents[1]
    files = {
        path for path in package.rglob("*.py")
        if not path.is_relative_to(package / "integrations")
    } | set((package / "schemas").glob("*.json"))
    return {
        path.relative_to(package).as_posix(): hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
        for path in sorted(files)
    }


def _portable(value, root, *, key="config", inputs=()):
    """Separate logical resource identities from machine-specific locators."""
    if isinstance(value, str) and key.split("/")[-2:-1] == ["overrides"] and "=" in value:
        name, raw = value.split("=", 1)
        return name + "=" + canonical(_portable(json.loads(raw), root, key=key + "/value", inputs=inputs))
    if isinstance(value, dict):
        return {
            name: _portable(item, root, key=key + "/" + name, inputs=inputs)
            for name, item in sorted(value.items())
        }
    if isinstance(value, list):
        return [
            _portable(item, root, key=key + "/" + str(i), inputs=inputs)
            for i, item in enumerate(value)
        ]
    if isinstance(value, str) and Path(value).is_absolute():
        selected = Path(value)
        try:
            return "project:" + selected.relative_to(root).as_posix()
        except ValueError:
            # Only declared, hashed resources have locator-independent identity.
            # An arbitrary absolute business value must not collapse to a key.
            if any(
                Path(path) == selected or Path(path).is_relative_to(selected)
                for path in inputs
            ):
                return "resource:" + key
            return value
    return value


def _input_name(path, plan, root):
    selected = Path(path)
    try:
        return "project:" + selected.relative_to(root).as_posix()
    except ValueError:
        pass
    candidates = []

    def visit(value, key):
        if isinstance(value, dict):
            for name, item in value.items():
                visit(item, key + "/" + name)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                visit(item, key + "/" + str(index))
        elif isinstance(value, str) and Path(value).is_absolute():
            target = Path(value)
            if selected == target or selected.is_relative_to(target):
                candidates.append(
                    (len(target.parts), key, selected.relative_to(target).as_posix())
                )

    visit(plan.config, "config")
    visit(plan.metadata, "metadata")
    if candidates:
        _, key, suffix = max(candidates)
        return "resource:" + key + "/" + suffix
    return "input:" + selected.name


@dataclass(frozen=True)
class ResolvedAssembly:
    spec: AssemblySpec
    root: Path
    order: tuple[str, ...]
    bindings: object
    plans: object
    lock_json: str

    @property
    def lock(self):
        return json.loads(self.lock_json)

    @property
    def fingerprint(self):
        return _hash(self.lock)

    def verify_inputs(self):
        self.verify_core()
        for plan in self.plans.values():
            plan.verify_inputs()

    def verify_core(self):
        if self.lock["core"] != core_identity():
            raise ComponentError(
                "input_changed",
                "Installed core implementation differs from assembly lock",
            )

    def closure(self, alias):
        selected = set()

        def visit(name):
            if name in selected:
                return
            selected.add(name)
            for target in self.bindings[name].values():
                visit(target)

        visit(alias)
        return tuple(name for name in self.order if name in selected)


def resolve(spec: AssemblySpec, context: ComponentContext, *, registry=None):
    registry = registry if registry is not None else default_registry()
    context.check()
    descriptors = {
        name: registry.provider(node.component, version=node.version).describe()
        for name, node in sorted(spec.components.items())
    }
    for role, name in spec.entrypoints.model_dump().items():
        if name not in descriptors:
            raise ComponentError(
                "missing_component", f"entrypoints.{role}: component alias is missing"
            )
        if descriptors[name].kind != role:
            raise ComponentError(
                "incompatible_contract", f"entrypoints.{role}: component kind differs"
            )
    bindings = {name: dict(node.bindings) for name, node in spec.components.items()}
    for name, descriptor in descriptors.items():
        ports = {port.name: port for port in descriptor.dependencies}
        if len(ports) != len(descriptor.dependencies):
            raise ComponentError(
                "invalid_plugin", f"components.{name}: duplicate dependency ports"
            )
        if ports and set(bindings[name]) - set(ports):
            raise ComponentError(
                "unknown_binding", f"components.{name}: unknown dependency port"
            )
        for port in ports.values():
            if port.name not in bindings[name]:
                candidates = []
                for target, candidate in descriptors.items():
                    if target == name:
                        continue
                    for capability in candidate.provides:
                        try:
                            require_capability(port.capability, capability)
                        except ComponentError:
                            continue
                        candidates.append(target)
                        break
                if len(candidates) == 1:
                    bindings[name][port.name] = candidates[0]
                elif len(candidates) > 1:
                    raise ComponentError(
                        "ambiguous_binding",
                        f"components.{name}.bindings.{port.name}: multiple compatible providers; bind explicitly",
                    )
                elif not port.optional:
                    raise ComponentError(
                        "missing_binding",
                        f"components.{name}.bindings.{port.name}: no compatible provider",
                    )
        for port, target in bindings[name].items():
            if target not in descriptors:
                raise ComponentError(
                    "missing_component",
                    f"components.{name}.bindings.{port}: unknown alias {target}",
                )
            if port in ports:
                _match(
                    ports[port].capability,
                    descriptors[target].provides,
                    f"components.{name}.bindings.{port}",
                )
        for capability in descriptor.requires:
            provided = [
                item
                for target in bindings[name].values()
                for item in descriptors[target].provides
            ]
            _match(
                capability,
                provided,
                f"components.{name}.requires.{capability.contract}",
            )

    order, visiting, visited = [], set(), set()

    def visit(name):
        if name in visiting:
            raise ComponentError(
                "dependency_cycle", f"components.{name}: dependency cycle"
            )
        if name in visited:
            return
        visiting.add(name)
        for target in sorted(set(bindings[name].values())):
            visit(target)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in sorted(descriptors):
        visit(name)

    plans = {}
    for name in order:
        node = spec.components[name]
        selected = ComponentSpec(
            component=node.component, version=node.version, config=node.config
        )
        plans[name] = registry.plan(
            selected, replace(context, workspace=context.workspace / name)
        )
    agent = plans[spec.entrypoints.agent]
    environment = plans[spec.entrypoints.environment]
    for role, plan in (("agent", agent), ("environment", environment)):
        if "episode_contract" not in plan.metadata:
            raise ComponentError(
                "missing_contract",
                f"entrypoints.{role}: plan needs an executable episode_contract",
            )
    require_episode(
        EpisodeContract.model_validate_json(
            canonical(agent.metadata["episode_contract"])
        ),
        EpisodeContract.model_validate_json(
            canonical(environment.metadata["episode_contract"])
        ),
        location=f"{spec.entrypoints.agent} -> {spec.entrypoints.environment}",
    )
    implementations = {}
    for name, plan in plans.items():
        provider = registry.provider(plan.descriptor.id)
        try:
            source = Path(inspect.getfile(type(provider))).read_bytes()
            implementation = hashlib.sha256(source).hexdigest()
        except (TypeError, OSError):
            implementation = None
        implementations[name] = implementation
    lock = logical_lock(spec, context.root, order, bindings, plans, implementations)
    return ResolvedAssembly(
        spec,
        context.root,
        tuple(order),
        MappingProxyType(
            {key: MappingProxyType(value) for key, value in bindings.items()}
        ),
        MappingProxyType(plans),
        canonical(lock),
    )


def logical_lock(spec, root, order, bindings, plans, implementations):
    """Rebuild the portable identity to bind transported plans to their lock."""
    records = {}
    for name, plan in plans.items():
        identities = [
            {"name": _input_name(item.path, plan, root), "sha256": item.sha256}
            for item in {
                (item.path, item.sha256): item for item in plan.inputs
            }.values()
        ]
        identities.sort(key=lambda item: (item["name"], item["sha256"]))
        if len({item["name"] for item in identities}) != len(identities):
            raise ComponentError(
                "ambiguous_input_identity",
                f"components.{name}: input names collide; declare their logical roots in config or metadata",
            )
        records[name] = {
            "descriptor": plan.descriptor.model_dump(mode="json"),
            "request": _portable(
                spec.components[name].model_dump(mode="json"),
                root,
                inputs=[item.path for item in plan.inputs],
            ),
            "configuration": _portable(
                plan.config, root, inputs=[item.path for item in plan.inputs]
            ),
            "metadata": _portable(
                plan.metadata,
                root,
                key="metadata",
                inputs=[item.path for item in plan.inputs],
            ),
            "inputs": identities,
            "bindings": dict(bindings[name]),
            "provider_source_sha256": implementations[name],
        }
    return {
        "schema_version": 1,
        "api": "roborsi.assembly/v1",
        "core": core_identity(),
        "entrypoints": spec.entrypoints.model_dump(),
        "order": list(order),
        "components": records,
    }


def _match(required, candidates, location):
    failures = []
    for candidate in candidates:
        try:
            require_capability(required, candidate, location=location)
            return
        except ComponentError as exc:
            failures.append(exc)
    if failures:
        raise failures[0]
    raise ComponentError(
        "missing_binding", f"{location}: required capability is not bound"
    )


@contextmanager
def open_graph(
    resolved, context, *, root_alias=None, registry=None, workspace_overrides=None
):
    """Open a selected dependency closure; unwind every predecessor on failure."""
    registry = registry if registry is not None else default_registry()
    selected = (
        resolved.closure(root_alias) if root_alias is not None else resolved.order
    )
    resolved.verify_core()
    for name in selected:
        resolved.plans[name].verify_inputs()
    with ExitStack() as stack:
        handles = {}
        for name in selected:
            context.check()
            child = replace(
                context,
                workspace=(workspace_overrides or {}).get(
                    name, context.workspace / name
                ),
                bindings={
                    port: handles[target]
                    for port, target in resolved.bindings[name].items()
                },
            )
            prepared = registry.prepare(resolved.plans[name], child)
            handle = stack.enter_context(registry.open(prepared, child))
            validate_business(resolved.plans[name].descriptor.kind, handle.value)
            handles[name] = handle
        yield MappingProxyType(handles)
