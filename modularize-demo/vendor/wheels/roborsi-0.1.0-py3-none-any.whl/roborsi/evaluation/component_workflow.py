# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Compose installed components into the existing batch/case evaluation workflow."""

from __future__ import annotations

import json
from contextlib import ExitStack, contextmanager
from pathlib import Path
from threading import Event, Lock

from roborsi.assembly.resolver import resolve
from roborsi.assembly.spec import AssemblySpec, RunSpec
from roborsi.components import default_registry
from roborsi.contracts import ComponentContext, ComponentError
from roborsi.evaluation.batch import BatchEvaluator, expand_cases
from roborsi.evaluation.deadline import CaseCancelled, CaseDeadline
from roborsi.evaluation.http_agent import HttpAgentLauncher
from roborsi.evaluation.http_benchmark import HttpBenchmarkExecutor, HttpBenchmarkLock
from roborsi.evaluation.orchestration import CaseOrchestrator
from roborsi.evaluation.result import write_json_atomic
from roborsi.evaluation.store import ResultStore
from roborsi.execution.bundle import verify_implementations
from roborsi.execution.runtime import RuntimeSupervisor
from roborsi.utils.rpc.http_abort import interrupt_http_calls
from roborsi.utils.rpc.http_rpc import HttpRpcClient


class ComponentCatalog:
    """Freeze discovery metadata, rechecking pinned inputs without a live host."""

    def __init__(self, source, supervisor):
        self.source, self.supervisor = source, supervisor

    def __getattr__(self, name):
        return getattr(self.source, name)

    def verify(self):
        if self.supervisor.deployments["environment"].backend == "http":
            self.source.verify()
        else:
            self.supervisor.resolved.verify_inputs()
            alias = self.supervisor.resolved.spec.entrypoints.environment
            verify_implementations(
                self.supervisor.resolved, self.supervisor.registry, alias
            )


class ComponentBenchmarkRegistry:
    def __init__(self, catalog):
        self.catalog = catalog

    def lock(self, benchmark):
        if benchmark != self.catalog.benchmark:
            raise KeyError(benchmark)
        self.catalog.verify()
        return self.catalog


class ComponentAgentLauncher:
    def __init__(self, supervisor, allocations):
        self.supervisor, self.allocations = supervisor, allocations

    def verify_version(self, version):
        if version != self.supervisor.resolved.fingerprint:
            raise ComponentError(
                "lock_changed",
                "Agent version must equal the pinned assembly fingerprint",
            )

    @contextmanager
    def start(self, case_dir, *, deadline=None, media_dir=None):
        key = str(Path(case_dir).parent.resolve())
        allocation = self.allocations.get(key, {}).get("agent")
        with self.supervisor.start(
            "agent",
            case_dir,
            deadline=deadline,
            media_dir=media_dir,
            allocation=allocation,
        ) as endpoint:
            launcher = HttpAgentLauncher(
                endpoint,
                startup_timeout_s=self.supervisor.deployments[
                    "agent"
                ].startup_timeout_s,
            )
            with launcher.start(
                case_dir, deadline=deadline, media_dir=media_dir
            ) as service:
                deployment = self.supervisor.deployments["agent"]
                contract = self.supervisor.resolved.plans[
                    self.supervisor.resolved.spec.entrypoints.agent
                ].metadata["episode_contract"]
                if (
                    deployment.backend == "http"
                    and contract.get("media") == "shared_filesystem"
                ):
                    remote = (
                        (
                            Path(deployment.media_root)
                            / self.supervisor.run.run_id
                            / Path(case_dir).parent.name
                            / "media"
                        )
                        if deployment.media_root
                        else Path(media_dir)
                    )
                    rpc = HttpRpcClient(endpoint)
                    try:
                        rpc.call(
                            "configure_episode",
                            kwargs={"media_dir": str(remote)},
                            timeout_s=deadline.remaining(5) if deadline else 5,
                        )
                    finally:
                        rpc.close()
                yield service


class ComponentBenchmarkExecutor:
    """Each owned case gets an isolated native environment and an atomic lease."""

    def __init__(self, supervisor, allocations, cancel):
        self.supervisor, self.allocations, self.cancel = supervisor, allocations, cancel
        self.guard = Lock()

    @contextmanager
    def start_adapter(self, lock, case_dir, *, deadline=None):
        if self.cancel.is_set():
            raise CaseCancelled("case cancelled before startup")
        key = str(Path(case_dir).resolve())
        with ExitStack() as stack:
            allocation = {}
            if self.supervisor.case_requirements:
                lease = stack.enter_context(
                    self.supervisor.pool.acquire(
                        self.supervisor.case_requirements,
                        deadline=deadline,
                        wait_s=self.supervisor.run.lease_timeout_s,
                    )
                )
                allocation = self.supervisor.allocations(lease)
            with self.guard:
                self.allocations[key] = allocation
            try:
                workspace = (
                    self.supervisor.workspace
                    / "cases"
                    / Path(case_dir).name
                    / "environment"
                )
                endpoint = stack.enter_context(
                    self.supervisor.start(
                        "environment",
                        workspace,
                        deadline=deadline,
                        allocation=allocation.get("environment"),
                    )
                )
                with interrupt_http_calls(deadline.check if deadline else None):
                    current = HttpBenchmarkLock(
                        endpoint, timeout_s=deadline.remaining(5) if deadline else 5
                    )
                if current.manifest_sha256 != lock.manifest_sha256:
                    raise ComponentError(
                        "input_changed",
                        "Case environment catalog differs from discovery",
                    )
                service = stack.enter_context(
                    HttpBenchmarkExecutor().start_adapter(
                        current, case_dir, deadline=deadline
                    )
                )
                yield service
            finally:
                with self.guard:
                    self.allocations.pop(key, None)


class CancellableOrchestrator(CaseOrchestrator):
    def __init__(self, *args, cancel, **kwargs):
        super().__init__(*args, **kwargs)
        self.cancel = cancel

    def run(self, *args, **kwargs):
        try:
            return super().run(*args, **kwargs, cancel_event=self.cancel)
        except CaseCancelled:
            # Cancellation before claim still publishes a terminal result for
            # each queued cell. The executor rejects startup before allocation.
            return super().run(*args, **kwargs)


class AssemblyResultStore(ResultStore):
    """Save assembly inputs with the batch claim, before the first case starts."""

    def __init__(self, root, resolved, run):
        super().__init__(root)
        self.resolved, self.run_spec = resolved, run

    def reserve_batch_run(self, run_id, plan):
        directory = super().reserve_batch_run(run_id, plan)
        write_json_atomic(directory / "assembly.lock.json", self.resolved.lock)
        write_json_atomic(directory / "run.json", self.run_spec.model_dump(mode="json"))
        return directory


def run_assembly(
    spec: AssemblySpec,
    run: RunSpec,
    *,
    root=None,
    registry=None,
    cancel_event=None,
    progress=None,
    expected_lock=None,
):
    """Resolve before allocation; run native scoring through existing machinery."""
    root = Path(root or Path.cwd()).resolve()
    registry = registry if registry is not None else default_registry()
    cancel = cancel_event if cancel_event is not None else Event()
    context = ComponentContext(
        root / run.workspace / run.run_id, root=root, cancelled=cancel
    )
    resolved = resolve(spec, context, registry=registry)
    if expected_lock is not None and expected_lock != resolved.lock:
        raise ComponentError("lock_changed", "Assembly changed after validation")
    supervisor = RuntimeSupervisor(resolved, run, context.workspace, registry)
    results = (root / run.results_root).resolve()
    if (results / run.run_id).exists():
        raise FileExistsError(f"run already exists: {run.run_id}")
    if run.resume_from:
        previous = results / run.resume_from
        old_lock = json.loads((previous / "assembly.lock.json").read_text())
        old_run = RunSpec.model_validate_json((previous / "run.json").read_text())
        if old_lock != resolved.lock or old_run.deployments != run.deployments:
            raise ComponentError(
                "resume_changed",
                "Resume requires unchanged assembly and explicit deployment settings",
            )
    supervisor.initialize()
    deadline = CaseDeadline(
        min(
            run.case_timeout_s, supervisor.deployments["environment"].startup_timeout_s
        ),
        cancel_event=cancel,
    )
    with supervisor.start(
        "environment", supervisor.workspace / "discovery", deadline=deadline
    ) as endpoint:
        with interrupt_http_calls(deadline.check):
            source = HttpBenchmarkLock(
                endpoint, timeout_s=deadline.remaining(run.timeout_s)
            )
    catalog = ComponentCatalog(source, supervisor)
    benchmarks = ComponentBenchmarkRegistry(catalog)
    cells = expand_cases(
        benchmarks,
        [catalog.benchmark],
        task_ids={catalog.benchmark: run.tasks} if run.tasks else None,
        seeds=run.seeds or None,
    )
    allocations = {}
    store = AssemblyResultStore(results, resolved, run)
    executor = ComponentBenchmarkExecutor(supervisor, allocations, cancel)
    launcher = ComponentAgentLauncher(supervisor, allocations)
    orchestrator = CancellableOrchestrator(
        benchmarks, store, launcher, executor, cancel=cancel
    )
    batch = BatchEvaluator(benchmarks, store, orchestrator)
    report = batch.run(
        run.run_id,
        cells,
        resolved.fingerprint,
        max_concurrent=run.max_concurrent,
        timeout_s=run.timeout_s,
        case_timeout_s=run.case_timeout_s,
        resume_from=run.resume_from,
        progress=progress,
    )
    directory = results / run.run_id
    write_json_atomic(directory / "deployments.json", supervisor.records)
    write_json_atomic(directory / "report.json", report.as_dict())
    write_json_atomic(supervisor.workspace / "report.json", report.as_dict())
    return report
