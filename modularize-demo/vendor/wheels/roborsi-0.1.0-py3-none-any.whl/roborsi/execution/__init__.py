# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Owned runtime hosts and resource leases for declarative assemblies."""
