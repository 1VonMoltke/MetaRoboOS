# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Transfer pinned local plans to generic service hosts without re-resolution."""

import hashlib
import inspect
import json
import shutil
from pathlib import Path
from types import MappingProxyType

from roborsi.assembly.resolver import ResolvedAssembly, logical_lock
from roborsi.assembly.spec import AssemblySpec
from roborsi.contracts import ComponentError, ComponentPlan
from roborsi.contracts.component import canonical


def bundle_document(resolved):
    return {
        "schema_version": 1,
        "spec": resolved.spec.model_dump(mode="json"),
        "root": str(resolved.root),
        "order": list(resolved.order),
        "bindings": {key: dict(value) for key, value in resolved.bindings.items()},
        "plans": {
            name: plan.model_dump(mode="json") for name, plan in resolved.plans.items()
        },
        "lock": resolved.lock,
        "fingerprint": resolved.fingerprint,
    }


def read_bundle(path):
    document = json.loads(Path(path).read_text())
    resolved = ResolvedAssembly(
        AssemblySpec.model_validate_json(json.dumps(document["spec"])),
        Path(document["root"]),
        tuple(document["order"]),
        MappingProxyType(
            {
                name: MappingProxyType(value)
                for name, value in document["bindings"].items()
            }
        ),
        MappingProxyType(
            {
                name: ComponentPlan.model_validate_json(json.dumps(value))
                for name, value in document["plans"].items()
            }
        ),
        json.dumps(document["lock"], sort_keys=True),
    )
    if resolved.fingerprint != document["fingerprint"]:
        raise ComponentError(
            "lock_changed", "Runtime assembly lock fingerprint differs"
        )
    names = set(resolved.spec.components)
    if (
        set(resolved.plans) != names
        or set(resolved.bindings) != names
        or set(resolved.order) != names
        or len(resolved.order) != len(names)
    ):
        raise ComponentError("lock_changed", "Runtime graph aliases differ from lock")
    seen = set()
    for name in resolved.order:
        if set(resolved.bindings[name].values()) - seen:
            raise ComponentError(
                "lock_changed", "Runtime graph order is not topological"
            )
        seen.add(name)
    rebuilt = logical_lock(
        resolved.spec,
        resolved.root,
        resolved.order,
        resolved.bindings,
        resolved.plans,
        {
            name: resolved.lock["components"][name]["provider_source_sha256"]
            for name in names
        },
    )
    if canonical(rebuilt) != canonical(resolved.lock):
        raise ComponentError(
            "lock_changed", "Runtime plans differ from their logical lock"
        )
    return resolved


def verify_implementations(resolved, registry, root_alias):
    for name in resolved.closure(root_alias):
        provider = registry.provider(
            resolved.plans[name].descriptor.id,
            version="==" + resolved.plans[name].descriptor.version,
        )
        if provider.describe() != resolved.plans[name].descriptor:
            raise ComponentError(
                "input_changed",
                f"components.{name}: installed descriptor differs from lock",
            )
        expected = resolved.lock["components"][name]["provider_source_sha256"]
        if expected:
            actual = hashlib.sha256(
                Path(inspect.getfile(type(provider))).read_bytes()
            ).hexdigest()
            if actual != expected:
                raise ComponentError(
                    "input_changed",
                    f"components.{name}: installed provider implementation differs from lock",
                )


def snapshot_inputs(resolved, directory):
    """Copy only declared inputs, keeping their original read-only mount paths.

    M4 runtime transport, not the M5 relocatable package export. Installed plugin
    distributions must be present in the selected container image.
    """
    directory = Path(directory)
    resolved.verify_inputs()
    groups = {}
    files = {
        Path(item.path) for plan in resolved.plans.values() for item in plan.inputs
    }
    roots = {
        resolved.root if source.is_relative_to(resolved.root) else source.parent
        for source in files
    }
    roots = {
        root
        for root in roots
        if not any(root != parent and root.is_relative_to(parent) for parent in roots)
    }
    for source in sorted(files):
        root = next(root for root in roots if source.is_relative_to(root))
        if root not in groups:
            groups[root] = directory / str(len(groups))
        destination = groups[root] / source.relative_to(root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        if (
            hashlib.sha256(source.read_bytes()).digest()
            != hashlib.sha256(destination.read_bytes()).digest()
        ):
            raise ComponentError(
                "input_changed", "Runtime input snapshot differs from original"
            )
    resolved.verify_inputs()
    return [(source, target) for target, source in groups.items()]
