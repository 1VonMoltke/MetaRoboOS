# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Generic plugin hosts expose the existing Agent RPC and Benchmark HTTP APIs."""

from __future__ import annotations

import argparse
import json
import os
import signal
import threading
from contextlib import ExitStack
from dataclasses import replace
from pathlib import Path

from roborsi.assembly.resolver import open_graph
from roborsi.components import default_registry
from roborsi.contracts import ComponentContext
from roborsi.execution.bundle import read_bundle, verify_implementations


class GraphAgent:
    """One episode owns one graph; facade cleanup cannot double-close its Agent."""

    def __init__(self, resolved, context, registry, alias):
        self.closed = False
        self.stack = ExitStack()
        try:
            handles = self.stack.enter_context(
                open_graph(
                    resolved,
                    context,
                    root_alias=alias,
                    registry=registry,
                    workspace_overrides={alias: context.workspace},
                )
            )
            self.agent = handles[alias].value
        except BaseException:
            self.stack.close()
            raise

    def reset(self, task):
        return self.agent.reset(task)

    def act(self, observation):
        return self.agent.act(observation)

    def __getattr__(self, name):
        # Optional observe_end/resume remain optional to AgentFacade.
        return getattr(self.agent, name)

    def close(self):
        if not self.closed:
            self.closed = True
            self.stack.close()


def agent_facade(resolved, context, registry, alias):
    from roborsi.evaluation.service_protocol import RoboRSIFacade
    from roborsi.evaluation.services import AgentFacade

    class ReusableFacade(RoboRSIFacade):
        """Sequential attachments get fresh per-episode graphs and replay state."""

        def __init__(self):
            super().__init__()
            self.sequence = 0
            self.started = False
            self.guard = threading.RLock()
            self.new_episode()
            self._rpc["component_info"] = lambda: component_info(resolved, "agent")
            self._rpc["configure_episode"] = self.configure_episode
            for name in self.inner._rpc:
                if name not in {"healthz", "shutdown"}:
                    self._rpc[name] = self.delegate(name)

        def new_episode(self):
            workspace = (
                context.workspace
                if self.sequence == 0
                else context.workspace / f"episode-{self.sequence}"
            )
            self.graph = GraphAgent(
                resolved, replace(context, workspace=workspace), registry, alias
            )
            self.inner = AgentFacade(self.graph)
            self.sequence += 1
            self.started = False

        def configure_episode(self, media_dir):
            with self.guard:
                if self.started and not self.graph.closed:
                    raise ValueError("cannot reconfigure an active episode")
                path = Path(media_dir)
                if not path.is_absolute() or path.is_symlink() or not path.is_dir():
                    raise ValueError(
                        "Agent media directory requires an available shared-filesystem mount"
                    )
                os.environ["ROBORSI_MEDIA_DIR"] = str(path)
                return {"ok": True}

        def delegate(self, name):
            def call(*args, **kwargs):
                with self.guard:
                    if name == "reset" and self.graph.closed:
                        self.new_episode()
                    if name == "reset":
                        self.started = True
                    return self.inner._rpc[name](*args, **kwargs)

            return call

        def close(self):
            self.graph.close()

    return ReusableFacade()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kind", choices=("agent", "environment"), required=True)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--ready", type=Path)
    parser.add_argument("--parent-watch", action="store_true")
    args = parser.parse_args(argv)
    resolved = read_bundle(args.bundle)
    alias = getattr(resolved.spec.entrypoints, args.kind)
    registry = default_registry()
    verify_implementations(resolved, registry, alias)
    stop = threading.Event()
    for name in (signal.SIGTERM, signal.SIGINT):
        signal.signal(name, lambda *args: stop.set())
    if args.parent_watch:
        from roborsi.utils.daemon import watch_parent_death

        watch_parent_death(stop.set)
    context = ComponentContext(
        args.workspace,
        root=resolved.root,
        cancelled=stop,
        secret_resolver=lambda name: os.environ[name],
    )
    args.workspace.mkdir(parents=True, exist_ok=True)
    if args.kind == "environment":
        from roborsi.evaluation.benchmark_http import (
            BenchmarkApplication,
            BenchmarkHttpServer,
        )

        class AssemblyApplication(BenchmarkApplication):
            def handle(self, method, path, body):
                if method == "GET" and path == "/v1/component":
                    return 200, component_info(resolved, "environment"), {}
                return super().handle(method, path, body)

        with open_graph(
            resolved,
            context,
            root_alias=alias,
            registry=registry,
            workspace_overrides={alias: args.workspace},
        ) as handles:
            value = handles[alias].value
            app = AssemblyApplication(value, args.workspace / "episodes")
            server = BenchmarkHttpServer((args.host, args.port), app)
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            try:
                _ready(args, resolved, value.name)
                stop.wait()
            finally:
                server.shutdown()
                app.close()
                server.server_close()
                worker.join(timeout=5)
    else:
        facade = agent_facade(resolved, context, registry, alias)
        worker = threading.Thread(
            target=facade.serve,
            kwargs={"transport": "http", "host": args.host, "port": args.port},
            daemon=True,
        )
        worker.start()
        try:
            _ready(args, resolved, None)
            while worker.is_alive() and not stop.wait(0.1):
                pass
        finally:
            facade._shutdown_event.set()
            worker.join(timeout=5)
            facade.close()


def _ready(args, resolved, benchmark):
    if args.ready:
        args.ready.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.ready.with_suffix(".next")
        temporary.write_text(
            json.dumps(
                {
                    "pid": os.getpid(),
                    "assembly": resolved.fingerprint,
                    "benchmark": benchmark,
                }
            )
        )
        temporary.replace(args.ready)


def component_info(resolved, role):
    alias = getattr(resolved.spec.entrypoints, role)
    return {
        "api": "roborsi.host/v1",
        "assembly": resolved.fingerprint,
        "role": role,
        "component": resolved.plans[alias].descriptor.id,
        "episode_contract": resolved.plans[alias].metadata["episode_contract"],
    }


if __name__ == "__main__":
    main()
