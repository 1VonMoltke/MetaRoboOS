# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Cross-process resource reservations with kernel-released ownership locks."""

from __future__ import annotations

import json
import os
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from roborsi.assembly.spec import Inventory
from roborsi.contracts import ComponentError


def _memory_mb():
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                return int(line.split()[1]) // 1024
    except OSError:
        pass
    return 0


@dataclass
class Lease:
    pool: object
    id: str
    descriptor: object
    resources: dict
    closed: bool = False

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.pool.release(self)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class ResourcePool:
    """Reserve declared CPU/memory/GPU/devices across cooperating workflows.

    This is admission control, not an OS limit for local processes. Docker also
    receives CPU/memory/device limits. Non-cooperating applications are outside
    this pool; GPU IDs must be explicitly supplied by the operator.
    """

    def __init__(self, root, inventory=None):
        self.root = Path(root).resolve()
        supplied = inventory or Inventory()
        self.inventory = {
            "cpus": supplied.cpus or float(os.cpu_count() or 1),
            "memory_mb": supplied.memory_mb or _memory_mb(),
            "gpus": list(supplied.gpus),
            "devices": list(supplied.devices),
        }
        if len(set(supplied.gpus)) != len(supplied.gpus) or len(
            set(supplied.devices)
        ) != len(supplied.devices):
            raise ComponentError(
                "invalid_inventory", "Resource inventory IDs must be unique"
            )

    @contextmanager
    def _ledger(self):
        import fcntl

        self.root.mkdir(parents=True, exist_ok=True)
        with (self.root / "mutex").open("a+") as mutex:
            fcntl.flock(mutex, fcntl.LOCK_EX)
            ledger_path = self.root / "ledger.json"
            ledger = (
                json.loads(ledger_path.read_text())
                if ledger_path.exists()
                else {"inventory": self.inventory, "leases": {}}
            )
            if ledger["inventory"] != self.inventory:
                raise ComponentError(
                    "inventory_conflict", "Shared lease root has a different inventory"
                )
            for lease_id in list(ledger["leases"]):
                path = self.root / (lease_id + ".lock")
                with path.open("a+") as probe:
                    try:
                        fcntl.flock(probe, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        continue
                    del ledger["leases"][lease_id]
                    path.unlink(missing_ok=True)
            try:
                yield ledger
            finally:
                temporary = self.root / "ledger.next"
                temporary.write_text(json.dumps(ledger, sort_keys=True))
                temporary.replace(ledger_path)

    def check_capacity(self, requirements):
        capacity = self.inventory
        if (
            requirements.cpus > capacity["cpus"]
            or (
                capacity["memory_mb"] and requirements.memory_mb > capacity["memory_mb"]
            )
            or requirements.gpus > len(capacity["gpus"])
            or set(requirements.devices) - set(capacity["devices"])
        ):
            raise ComponentError(
                "insufficient_resources",
                "Declared resources exceed the explicit resource inventory",
            )

    def acquire(self, requirements, *, deadline=None, wait_s=30.0):
        import fcntl

        self.check_capacity(requirements)
        expires = time.monotonic() + wait_s
        while True:
            if deadline is not None:
                deadline.check()
            with self._ledger() as ledger:
                active = list(ledger["leases"].values())
                cpus = sum(item["cpus"] for item in active)
                memory = sum(item["memory_mb"] for item in active)
                used_gpus = {gpu for item in active for gpu in item["gpu_ids"]}
                used_devices = {device for item in active for device in item["devices"]}
                available = [
                    gpu for gpu in self.inventory["gpus"] if gpu not in used_gpus
                ]
                if (
                    cpus + requirements.cpus <= self.inventory["cpus"]
                    and (
                        not self.inventory["memory_mb"]
                        or memory + requirements.memory_mb
                        <= self.inventory["memory_mb"]
                    )
                    and len(available) >= requirements.gpus
                    and not set(requirements.devices) & used_devices
                ):
                    lease_id = uuid.uuid4().hex
                    descriptor = (self.root / (lease_id + ".lock")).open("a+")
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    resources = {
                        "cpus": requirements.cpus,
                        "memory_mb": requirements.memory_mb,
                        "gpu_ids": available[: requirements.gpus],
                        "devices": list(requirements.devices),
                        "pid": os.getpid(),
                    }
                    ledger["leases"][lease_id] = resources
                    return Lease(self, lease_id, descriptor, resources)
            if time.monotonic() >= expires:
                raise ComponentError(
                    "resource_busy", "Timed out waiting for reserved resources"
                )
            time.sleep(min(0.05, max(0.0, expires - time.monotonic())))

    def release(self, lease):
        import fcntl

        with self._ledger() as ledger:
            ledger["leases"].pop(lease.id, None)
            fcntl.flock(lease.descriptor, fcntl.LOCK_UN)
            lease.descriptor.close()
            (self.root / (lease.id + ".lock")).unlink(missing_ok=True)

    def active(self):
        with self._ledger() as ledger:
            return dict(ledger["leases"])
