# Copyright 2026 The HEART Authors.
# Licensed under the Apache License, Version 2.0 (the "License");
"""Own generic local/container hosts; HTTP deployments are attachments only."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import uuid
from contextlib import ExitStack, contextmanager
from pathlib import Path
from threading import Lock

from roborsi.assembly.spec import Deployment
from roborsi.contracts import ComponentError, ResourceRequirements
from roborsi.evaluation.benchmark_client import BenchmarkClient
from roborsi.evaluation.deadline import CaseDeadline
from roborsi.evaluation.result import write_json_atomic
from roborsi.execution.bundle import (
    bundle_document,
    snapshot_inputs,
    verify_implementations,
)
from roborsi.execution.host import component_info
from roborsi.execution.leases import ResourcePool
from roborsi.utils.daemon import pick_free_port
from roborsi.utils.rpc.http_rpc import HttpRpcClient


def combined(requirements):
    items = tuple(requirements)
    devices = [device for item in items for device in item.devices]
    if len(set(devices)) != len(devices):
        raise ComponentError(
            "resource_conflict", "Owned components require the same exclusive device"
        )
    return ResourceRequirements(
        cpus=sum(item.cpus for item in items) or 0.001,
        memory_mb=sum(item.memory_mb for item in items),
        gpus=sum(item.gpus for item in items),
        devices=tuple(devices),
    )


class RuntimeSupervisor:
    def __init__(self, resolved, run, workspace, registry):
        self.resolved, self.run, self.workspace, self.registry = (
            resolved,
            run,
            Path(workspace),
            registry,
        )
        self.deployments = {
            role: run.deployments.get(alias, run.deployments.get(role, Deployment()))
            for role, alias in resolved.spec.entrypoints.model_dump().items()
        }
        allowed = {
            "agent",
            "environment",
            *resolved.spec.entrypoints.model_dump().values(),
        }
        if set(run.deployments) - allowed:
            raise ComponentError(
                "invalid_deployment",
                "Only entrypoint closures are deployment units; bind dependency plugins inside a closure",
            )
        for role, alias in resolved.spec.entrypoints.model_dump().items():
            if role != alias and role in run.deployments and alias in run.deployments:
                raise ComponentError(
                    "invalid_deployment", f"Duplicate deployment for {role}"
                )
            if (
                self.deployments[role].backend
                not in resolved.plans[alias].descriptor.execution_modes
            ):
                raise ComponentError(
                    "unsupported_execution",
                    f"{role} does not support the selected deployment backend",
                )
            if self.deployments[role].backend == "http" and run.max_concurrent != 1:
                raise ComponentError(
                    "unsupported_concurrency",
                    "Attached endpoints own one episode; max_concurrent must be 1",
                )
        self.pool = ResourcePool(self.path(run.lease_root), run.inventory)
        self.requirements = {}
        for role, alias in resolved.spec.entrypoints.model_dump().items():
            deployment = self.deployments[role]
            if deployment.backend == "http":
                continue
            declared = combined(
                resolved.plans[name].descriptor.resources
                for name in resolved.closure(alias)
            )
            override = deployment.resources
            if override and (
                override.cpus < declared.cpus
                or override.memory_mb < declared.memory_mb
                or override.gpus < declared.gpus
                or not set(declared.devices) <= set(override.devices)
            ):
                raise ComponentError(
                    "invalid_resources",
                    "Deployment reservations cannot understate the closure's declared requirements",
                )
            self.requirements[role] = override or declared
        self.case_requirements = (
            combined(self.requirements.values()) if self.requirements else None
        )
        if self.case_requirements:
            self.pool.check_capacity(self.case_requirements)
        self.records, self.guard = [], Lock()
        self.bundle = self.workspace / "assembly.bundle.json"

    def path(self, value):
        return (self.resolved.root / value).resolve()

    def initialize(self):
        self.resolved.verify_inputs()
        for role in self.requirements:
            verify_implementations(
                self.resolved,
                self.registry,
                getattr(self.resolved.spec.entrypoints, role),
            )
        # Claim the runtime directory before allocating anything; concurrent runs
        # with the same run_id cannot overwrite readiness files or logs.
        self.workspace.mkdir(parents=True, exist_ok=False)
        write_json_atomic(self.bundle, bundle_document(self.resolved))
        write_json_atomic(self.workspace / "assembly.lock.json", self.resolved.lock)
        write_json_atomic(self.workspace / "run.json", self.run.model_dump(mode="json"))

    def allocations(self, lease):
        result, offset = {}, 0
        for role, requirements in self.requirements.items():
            result[role] = {
                **lease.resources,
                "gpu_ids": lease.resources["gpu_ids"][
                    offset : offset + requirements.gpus
                ],
                "devices": list(requirements.devices),
                "cpus": requirements.cpus,
                "memory_mb": requirements.memory_mb,
            }
            offset += requirements.gpus
        return result

    def _health(self, role, endpoint, timeout):
        if role == "agent":
            rpc = HttpRpcClient(endpoint)
            try:
                rpc.call("healthz", timeout_s=timeout)
                return rpc.call("component_info", timeout_s=timeout)
            finally:
                rpc.close()
        client = BenchmarkClient(endpoint)
        client.transport.request("GET", "/v1/health", timeout_s=timeout)
        return client.transport.request("GET", "/v1/component", timeout_s=timeout)[1]

    def _wait(self, role, endpoint, deadline, process=None):
        while True:
            deadline.check()
            if process is not None and process.poll() is not None:
                raise ComponentError(
                    "host_exited",
                    f"{role} host exited before readiness; inspect host.log",
                )
            try:
                info = self._health(role, endpoint, deadline.remaining(0.5))
            except Exception:
                deadline.check()
                time.sleep(min(0.05, deadline.remaining()))
                continue
            if info != component_info(self.resolved, role):
                raise ComponentError(
                    "incompatible_contract",
                    f"Attached {role} host does not match the pinned assembly",
                )
            return info

    @contextmanager
    def start(self, role, workspace, *, deadline=None, media_dir=None, allocation=None):
        deployment = self.deployments[role]
        workspace = Path(workspace).resolve()
        endpoint = deployment.endpoint
        startup = CaseDeadline(
            min(deployment.startup_timeout_s, deadline.remaining())
            if deadline
            else deployment.startup_timeout_s,
            cancel_event=getattr(deadline, "_cancel_event", None),
        )
        record = {
            "role": role,
            "backend": deployment.backend,
            "assembly": self.resolved.fingerprint,
            "owned": deployment.backend != "http",
            "cleaned": False,
        }
        process = log = None
        container = None
        with ExitStack() as stack:
            try:
                if deployment.backend == "http":
                    self._wait(role, endpoint, startup)
                else:
                    alias = getattr(self.resolved.spec.entrypoints, role)
                    for name in self.resolved.closure(alias):
                        self.resolved.plans[name].verify_inputs()
                    verify_implementations(self.resolved, self.registry, alias)
                    if allocation is None:
                        lease = stack.enter_context(
                            self.pool.acquire(
                                self.requirements[role],
                                deadline=startup,
                                wait_s=self.run.lease_timeout_s,
                            )
                        )
                        allocation = lease.resources
                    workspace.mkdir(parents=True, exist_ok=True)
                    port = pick_free_port()
                    endpoint = f"http://127.0.0.1:{port}"
                    child_env = {
                        "PATH": "/usr/local/bin:" + os.defpath,
                        "LANG": "C.UTF-8",
                        "PYTHONUNBUFFERED": "1",
                        "HOME": str(workspace / ".home"),
                        **deployment.environment,
                        "ROBORSI_REPO_ROOT": str(self.resolved.root),
                    }
                    if media_dir is not None:
                        child_env["ROBORSI_MEDIA_DIR"] = str(Path(media_dir).resolve())
                    if allocation["gpu_ids"]:
                        child_env["CUDA_VISIBLE_DEVICES"] = ",".join(
                            allocation["gpu_ids"]
                        )
                    for name in deployment.credential_env:
                        if name not in os.environ:
                            raise ComponentError(
                                "missing_secret",
                                f"Missing credential environment reference: {name}",
                            )
                        child_env[name] = os.environ[name]
                    command = [
                        deployment.python or sys.executable,
                        "-I",
                        "-B",
                        "-m",
                        "roborsi.execution.host",
                        "--kind",
                        role,
                        "--bundle",
                        str(self.bundle),
                        "--workspace",
                        str(workspace),
                        "--port",
                        str(port),
                        "--ready",
                        str(workspace / "ready.json"),
                        "--parent-watch",
                    ]
                    if deployment.backend == "docker":
                        container = "roborsi-component-" + uuid.uuid4().hex
                        record["container"] = container
                        command[0] = "python3"
                        mounts = [
                            (self.workspace, self.workspace, True),
                            (workspace, workspace, False),
                        ]
                        staged = snapshot_inputs(
                            self.resolved, workspace / "input-snapshot"
                        )
                        mounts.extend(
                            (source, target, True) for source, target in staged
                        )
                        if media_dir is not None:
                            mounts.append(
                                (
                                    Path(media_dir).resolve(),
                                    Path(media_dir).resolve(),
                                    True,
                                )
                            )
                        mounts.extend(
                            (self.path(m.source), Path(m.target), m.readonly)
                            for m in deployment.mounts
                        )
                        # Docker cannot create a child mountpoint through a
                        # read-only parent bind. Create only mount placeholders
                        # in our staged input tree, never in the original inputs.
                        for staged_source, staged_target in staged:
                            for source, target, _ in mounts:
                                if target != staged_target and target.is_relative_to(
                                    staged_target
                                ):
                                    placeholder = staged_source / target.relative_to(
                                        staged_target
                                    )
                                    if source.is_dir():
                                        placeholder.mkdir(parents=True, exist_ok=True)
                                    else:
                                        placeholder.parent.mkdir(
                                            parents=True, exist_ok=True
                                        )
                                        placeholder.touch(exist_ok=True)
                        targets = [str(item[1]) for item in mounts]
                        if len(targets) != len(set(targets)):
                            raise ComponentError(
                                "mount_conflict", "Duplicate runtime mount targets"
                            )
                        docker = [
                            "docker",
                            "run",
                            "--rm",
                            "-i",
                            "--name",
                            container,
                            "--user",
                            f"{os.getuid()}:{os.getgid()}",
                            "--network",
                            "host",
                            "--label",
                            "roborsi.component-run=" + self.run.run_id,
                            "--cpus",
                            str(allocation["cpus"]),
                            "--cap-drop",
                            "ALL",
                            "--security-opt",
                            "no-new-privileges",
                        ]
                        if allocation["memory_mb"]:
                            docker += ["--memory", f"{allocation['memory_mb']}m"]
                        if allocation["gpu_ids"]:
                            docker += [
                                "--gpus",
                                '"device=' + ",".join(allocation["gpu_ids"]) + '"',
                            ]
                            # In a container CUDA sees the selected devices re-indexed.
                            child_env.pop("CUDA_VISIBLE_DEVICES", None)
                        for device in allocation["devices"]:
                            docker += ["--device", device]
                        for source, target, readonly in mounts:
                            if (
                                not source.exists()
                                or "," in str(source)
                                or "," in str(target)
                            ):
                                raise ComponentError(
                                    "invalid_mount",
                                    "Runtime mount source is unavailable or contains commas",
                                )
                            docker += [
                                "--mount",
                                f"type=bind,src={source},dst={target}"
                                + (",readonly" if readonly else ""),
                            ]
                        # Values go through stdin-owned process env, never argv/logs.
                        for key in child_env:
                            docker += ["--env", key]
                        docker += [
                            "--workdir",
                            str(workspace),
                            "--entrypoint",
                            "python3",
                            deployment.image,
                            *command[1:],
                        ]
                        command = docker
                        record["image"] = deployment.image
                    log = (workspace / "host.log").open("a")
                    process = subprocess.Popen(
                        command,
                        stdin=subprocess.PIPE,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        env=child_env,
                        cwd=workspace,
                        start_new_session=True,
                    )
                    record.update(
                        pid=process.pid,
                        allocation=allocation,
                        workspace=str(workspace),
                        credential_env=list(deployment.credential_env),
                    )
                    self._wait(role, endpoint, startup, process)
                    if container:
                        inspected = subprocess.run(
                            ["docker", "inspect", container],
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=10,
                        )
                        observed = json.loads(inspected.stdout)[0]
                        record["docker_observed"] = {
                            "id": observed["Id"],
                            "image": observed["Image"],
                            "nano_cpus": observed["HostConfig"]["NanoCpus"],
                            "memory_bytes": observed["HostConfig"]["Memory"],
                            "devices": observed["HostConfig"]["Devices"],
                            "device_requests": observed["HostConfig"]["DeviceRequests"],
                        }
                record.update(endpoint=endpoint, ready=True)
                yield endpoint
            finally:
                try:
                    if process is not None:
                        self._stop(process, container)
                    elif container is not None:
                        self._remove_container(container)
                    record["cleaned"] = True
                finally:
                    if log is not None:
                        log.close()
                    with self.guard:
                        self.records.append(record)
                        write_json_atomic(
                            self.workspace / "deployments.json", self.records
                        )

    @staticmethod
    def _remove_container(container):
        result = subprocess.run(
            ["docker", "rm", "-f", container],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode and "No such container" not in result.stderr:
            raise ComponentError(
                "cleanup_failed", "Could not remove owned component container"
            )

    @classmethod
    def _stop(cls, process, container):
        try:
            if process.stdin:
                process.stdin.close()
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
        finally:
            # The group can contain child workers even after the host has exited.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if container is not None:
                cls._remove_container(container)
