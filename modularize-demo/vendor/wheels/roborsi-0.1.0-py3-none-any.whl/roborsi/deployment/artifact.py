"""Export immutable deployment directories and reconstruct their runtime paths."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from pathlib import Path, PurePosixPath

from roborsi.assembly.resolver import resolve
from roborsi.assembly.spec import RunSpec
from roborsi.components import default_registry
from roborsi.contracts import ComponentContext
from roborsi.deployment import DEPLOYMENT_API
from roborsi.deployment.wheels import dependency_closure, sha256, verify_installed
from roborsi.deployment.runtime import qualify_runtimes
from roborsi.execution.bundle import bundle_document, read_bundle

PATH_TOKEN = "$roborsi.path"
OVERRIDE_TOKEN = "$roborsi.override"
JSON_TOKEN = "$roborsi.json"


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def identity(document):
    return hashlib.sha256(canonical({k: v for k, v in document.items() if k != "fingerprint"}).encode()).hexdigest()


def _relative(value):
    path = PurePosixPath(value)
    if not value or path.is_absolute() or ".." in path.parts or "\\" in value or path.as_posix() != value:
        raise ValueError(f"invalid artifact path: {value}")
    return path


def _regular(path):
    if any(p.is_symlink() for p in (path, *path.parents)) or not path.is_file():
        raise ValueError(f"deployment inputs must be regular unlinked files: {path}")


def verify_artifact(directory):
    directory = Path(directory).resolve()
    _regular(directory / "deployment.json")
    document = json.loads((directory / "deployment.json").read_text())
    if document.get("api") != DEPLOYMENT_API or document.get("schema_version") != 1:
        raise ValueError("unsupported deployment schema; explicit migration required")
    if document.get("fingerprint") != identity(document):
        raise ValueError("deployment manifest identity differs")
    expected = document["files"]
    actual = set()
    for path in directory.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"linked deployment member: {path}")
        if path.is_file() and path != directory / "deployment.json":
            actual.add(path.relative_to(directory).as_posix())
    if actual != set(expected):
        raise ValueError("deployment file inventory differs")
    for name, digest in expected.items():
        _relative(name)
        path = directory / name
        _regular(path)
        if sha256(path) != digest:
            raise ValueError(f"deployment content differs: {name}")
    return document


def _encode(value, mappings, *, field=""):
    if isinstance(value, dict):
        if any(token in value for token in (PATH_TOKEN, OVERRIDE_TOKEN, JSON_TOKEN)):
            raise ValueError("configuration uses a reserved deployment token")
        return {key: _encode(item, mappings, field=key) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(item, mappings, field=field) for item in value]
    if isinstance(value, str):
        if field in {"configuration_json", "metadata_json"}:
            return {JSON_TOKEN: _encode(json.loads(value), mappings)}
        if field == "overrides" and "=" in value:
            path, raw = value.split("=", 1)
            return {OVERRIDE_TOKEN: {"path": path, "value": _encode(json.loads(raw), mappings)}}
        if Path(value).is_absolute() and field not in {"target", "devices", "media_root"}:
            selected = Path(value)
            for source, base, prefix in sorted(mappings, key=lambda item: -len(item[0].parts)):
                if selected == source or selected.is_relative_to(source):
                    suffix = selected.relative_to(source).as_posix()
                    return {PATH_TOKEN: {"base": base, "path": (PurePosixPath(prefix) / suffix).as_posix()}}
            raise ValueError(f"undeclared absolute locator ({field}): {value}; declare its asset root")
    return value


def _decode(value, roots):
    if isinstance(value, dict):
        if set(value) == {JSON_TOKEN}:
            return json.dumps(_decode(value[JSON_TOKEN], roots), sort_keys=True)
        if set(value) == {PATH_TOKEN}:
            token = value[PATH_TOKEN]
            path = _relative(token["path"])
            if token["base"] not in roots:
                raise ValueError("unknown deployment path base")
            return str(roots[token["base"]] / path)
        if set(value) == {OVERRIDE_TOKEN}:
            token = value[OVERRIDE_TOKEN]
            return token["path"] + "=" + json.dumps(_decode(token["value"], roots))
        return {key: _decode(item, roots) for key, item in value.items()}
    if isinstance(value, list):
        return [_decode(item, roots) for item in value]
    return value


def _provider_distributions(registry, resolved):
    origins = {item["id"]: item["origin"] for item in registry.entries()}
    result = set()
    for plan in resolved.plans.values():
        origin = origins[plan.descriptor.id]
        if origin in {"explicit", "entry_point", "builtin"}:
            raise ValueError("export requires independently installed provider distributions")
        result.add(origin)
    return result


def export_artifact(spec, run, *, root, wheelhouse, output, requirements=(), assets=None, archive_images=True):
    root, output = Path(root).resolve(), Path(output).absolute()
    if output.exists():
        raise FileExistsError(f"deployment output already exists: {output}")
    if run.resume_from:
        raise ValueError("export a fresh RunSpec; resume requires explicitly transferred prior results")
    registry = default_registry()
    resolved = resolve(spec, ComponentContext(root / ".deployment-plan", root=root), registry=registry)
    for plan in resolved.plans.values():
        if plan.metadata.get("missing_assets"):
            raise ValueError(f"missing native assets: {plan.metadata['missing_assets']}")
    requested = sorted({"roborsi", "roborsi-sdk", *_provider_distributions(registry, resolved), *requirements})
    wheels = dependency_closure(wheelhouse, requested)
    owners = verify_installed(wheels)
    site = Path(sysconfig.get_path("purelib")).resolve()
    mappings = [(root, "project", "."), (site, "site", ".")]
    for name, path in sorted((assets or {}).items()):
        import re

        if not re.fullmatch(r"[a-z][a-z0-9_-]*", name):
            raise ValueError("asset root names must be lowercase identifiers")
        selected = Path(path).absolute()
        if not selected.exists() or selected.is_symlink():
            raise ValueError(f"missing or linked asset root: {name}")
        mappings.append((selected.resolve(), "assets", name))
    inputs = {Path(item.path): item for plan in resolved.plans.values() for item in plan.inputs}
    from roborsi.contracts import FileIdentity

    for source, base, _ in mappings:
        if base == "assets":
            for path in ([source] if source.is_file() else source.rglob("*")):
                if path.is_symlink():
                    raise ValueError(f"linked declared asset: {path}")
                if path.is_file():
                    inputs[path] = FileIdentity.capture(path)
    for path in inputs:
        _regular(path)
        if not any(path == start or path.is_relative_to(start) for start, _, _ in mappings):
            raise ValueError(f"input outside declared roots: {path}; use --asset NAME=PATH")
    run_document = run.model_dump(mode="json")
    image_info = {}
    for deployment in run_document["deployments"].values():
        if deployment["backend"] == "docker":
            reference = deployment["image"]
            if reference not in image_info:
                image_info[reference] = json.loads(subprocess.check_output(["docker", "image", "inspect", reference], text=True))[0]
            # docker load reliably restores content IDs, not registry RepoDigests.
            deployment["image"] = image_info[reference]["Id"]
    for name in ("results_root", "workspace", "lease_root"):
        if Path(run_document[name]).is_absolute() or ".." in Path(run_document[name]).parts:
            raise ValueError(f"RunSpec.{name} must be relative for portable deployment")
    for deployment in run_document["deployments"].values():
        if deployment["backend"] == "local" and deployment.get("python"):
            if Path(deployment["python"]).absolute() != Path(sys.executable).absolute():
                raise ValueError("local export requires the selected installed Python; use pinned images for heterogeneous runtimes")
            deployment["python"] = None
    qualification = qualify_runtimes(resolved, run, registry, owners, [source for source, base, _ in mappings if base == "assets"])
    portable = _encode({"assembly": bundle_document(resolved), "run": run_document}, mappings)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".roborsi-export-", dir=output.parent) as temporary:
        staging = Path(temporary) / "artifact"
        (staging / "wheels").mkdir(parents=True)
        (staging / "project").mkdir()
        (staging / "assets").mkdir()
        for path, item in sorted(inputs.items()):
            token = _encode(str(path), mappings)[PATH_TOKEN]
            if token["base"] == "site":
                if token["path"] not in owners:
                    raise ValueError(f"undeclared installed input: {token['path']}")
                continue
            destination = staging / token["base"] / token["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            if sha256(destination) != item.sha256:
                raise ValueError("input changed during deployment export")
        for wheel in wheels.values():
            shutil.copyfile(wheel.path, staging / "wheels" / wheel.path.name)
        provenance_file = Path(wheelhouse) / "wheel-provenance.json"
        if provenance_file.is_file():
            from packaging.utils import canonicalize_name

            provenance = []
            for record in json.loads(provenance_file.read_text()):
                name = canonicalize_name(record["name"])
                if name in wheels:
                    if record["sha256"] != wheels[name].digest:
                        raise ValueError(f"dependency provenance differs: {name}")
                    provenance.append(record)
            (staging / "wheel-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
        (staging / "requirements.lock").write_text("".join(
            f"{name}=={wheel.version} --hash=sha256:{wheel.digest}\n"
            for name, wheel in sorted(wheels.items())
        ))
        (staging / "assembly.template.json").write_text(json.dumps(portable, indent=2) + "\n")
        shutil.copyfile(Path(__file__).with_name("install.py"), staging / "install.py")
        images = []
        for image, info in sorted(image_info.items()):
            record = {"reference": image, "image_id": info["Id"], "archive": None}
            if archive_images:
                (staging / "images").mkdir(exist_ok=True)
                name = "images/" + info["Id"].split(":")[1] + ".tar"
                subprocess.run(["docker", "save", "-o", str(staging / name), image], check=True)
                record["archive"] = name
            images.append(record)
        document = {
            "schema_version": 1, "api": DEPLOYMENT_API,
            "python": {"implementation": platform.python_implementation(), "version": ".".join(platform.python_version_tuple()[:2]),
                       "system": platform.system(), "machine": platform.machine()},
            "requirements": requested,
            "packages": {name: {"version": w.version, "wheel": "wheels/" + w.path.name, "sha256": w.digest}
                         for name, w in sorted(wheels.items())},
            "images": images,
            "prerequisites": {
                "credential_env": sorted({key for d in run.deployments.values() for key in d.credential_env}),
                "http_endpoints": sorted({d.endpoint for d in run.deployments.values() if d.backend == "http"}),
                "gpu_ids": list(run.inventory.gpus), "devices": list(run.inventory.devices),
                "native_runtime": "Native simulator/driver dependencies must be in the declared wheel closure or pinned runtime image.",
            },
            "assembly_fingerprint": resolved.fingerprint,
            "runtime_qualification": qualification,
            "files": {p.relative_to(staging).as_posix(): sha256(p) for p in sorted(staging.rglob("*")) if p.is_file()},
        }
        document["fingerprint"] = identity(document)
        (staging / "deployment.json").write_text(json.dumps(document, indent=2) + "\n")
        resolved.verify_inputs()
        verify_artifact(staging)
        staging.rename(output)
    return document


def installed_wheels(directory):
    document = verify_artifact(directory)
    required = document["python"]
    actual = {"implementation": platform.python_implementation(), "version": ".".join(platform.python_version_tuple()[:2]),
              "system": platform.system(), "machine": platform.machine()}
    if required != actual:
        raise ValueError("deployment Python/platform differs; re-export for this target")
    wheels = dependency_closure(Path(directory) / "wheels", document["requirements"])
    if {name: {"version": w.version, "wheel": "wheels/" + w.path.name, "sha256": w.digest}
        for name, w in sorted(wheels.items())} != document["packages"]:
        raise ValueError("deployment dependency graph differs from manifest")
    verify_installed(wheels)
    return document


def materialize(directory, workspace):
    directory, workspace = Path(directory).resolve(), Path(workspace).absolute()
    document = installed_wheels(directory)
    if workspace.exists():
        raise FileExistsError(f"deployment workspace exists: {workspace}")
    workspace.mkdir(parents=True)
    try:
        for name in ("project", "assets"):
            shutil.copytree(directory / name, workspace / name)
        template = json.loads((directory / "assembly.template.json").read_text())
        expanded = _decode(template, {"project": workspace / "project", "assets": workspace / "assets",
                                      "site": Path(sysconfig.get_path("purelib")).resolve()})
        path = workspace / "assembly.bundle.json"
        path.write_text(json.dumps(expanded["assembly"], indent=2) + "\n")
        resolved = read_bundle(path)
        if resolved.fingerprint != document["assembly_fingerprint"]:
            raise ValueError("reconstructed assembly identity differs")
        resolved.verify_inputs()
        run = RunSpec.model_validate_json(json.dumps(expanded["run"]))
        registry = default_registry()
        replanned = resolve(resolved.spec, ComponentContext(workspace / ".verify", root=resolved.root), registry=registry)
        if replanned.lock != resolved.lock:
            raise ValueError("installed providers reconstruct a different assembly")
        (workspace / "run.json").write_text(run.model_dump_json(indent=2) + "\n")
        (workspace / "deployment-identity.json").write_text(json.dumps({"fingerprint": document["fingerprint"]}) + "\n")
        return resolved, run
    except BaseException:
        shutil.rmtree(workspace)
        raise


def runtime_prerequisites(directory):
    document = installed_wheels(directory)
    for name in document["prerequisites"]["credential_env"]:
        if not os.environ.get(name):
            raise ValueError(f"missing runtime credential environment variable: {name}")
    for device in document["prerequisites"]["devices"]:
        if not Path(device).exists():
            raise ValueError(f"missing runtime device: {device}")
    for record in document["images"]:
        info = json.loads(subprocess.check_output(["docker", "image", "inspect", record["image_id"]], text=True))[0]
        if info["Id"] != record["image_id"]:
            raise ValueError("runtime image differs from deployment identity")
    return document
