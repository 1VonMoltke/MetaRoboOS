"""Qualify the actual local or immutable-image runtime before exporting it."""

from __future__ import annotations

import hashlib
import importlib.util
import inspect
import json
import subprocess
import sysconfig
import uuid
from importlib import metadata
from pathlib import Path

from roborsi.assembly.resolver import core_identity
from roborsi.assembly.spec import Deployment

PROBE = r'''
import hashlib, importlib.util, inspect, json, os, sys
from importlib import metadata
from pathlib import Path
from roborsi.assembly.resolver import core_identity
from roborsi.components import default_registry
from roborsi.utils.config import get_project_env
request = json.loads(sys.argv[1])
r = default_registry()
plugins = {}
for name in request['components']:
    p = r.provider(name)
    plugins[name] = {'descriptor': p.describe().model_dump(mode='json'),
                    'source': hashlib.sha256(Path(inspect.getfile(type(p))).read_bytes()).hexdigest()}
requirements = request['native']
modules = {name: bool(importlib.util.find_spec(name)) for name in requirements['modules']}
assets = {name: bool(get_project_env(name) and Path(get_project_env(name)).is_dir()) for name in requirements['asset_env']}
provenance = {name: get_project_env(name) for name in requirements.get('provenance_env', [])}
distributions = {d.metadata['Name']: d.version for d in metadata.distributions()}
distribution_files = {}
for name in request['distributions']:
    d = metadata.distribution(name)
    distribution_files[name] = {'version': d.version, 'files': {
        str(p): hashlib.sha256(Path(d.locate_file(p)).read_bytes()).hexdigest()
        for p in d.files or () if str(p).startswith(('roborsi/', 'robots/', 'benchmarks/'))
        and not str(p).endswith(('.pyc', '.pyo'))
    }}
print(json.dumps({'core': core_identity(), 'plugins': plugins, 'modules': modules, 'assets': assets, 'provenance': provenance, 'distributions': distributions, 'distribution_files': distribution_files}))
'''


def qualify_runtimes(resolved, run, registry, owners, asset_roots):
    result = {}
    site = Path(sysconfig.get_path("purelib")).resolve()
    origins = {item["id"]: item["origin"] for item in registry.entries()}
    for role, alias in resolved.spec.entrypoints.model_dump().items():
        deployment = run.deployments.get(alias, run.deployments.get(role, Deployment()))
        if deployment.backend == "http":
            result[role] = {"backend": "http", "qualification": "external attachment; assembly handshake required at connection"}
            continue
        expected = {}
        requirements = {"modules": set(), "asset_env": set(), "provenance_env": set()}
        for name in resolved.closure(alias):
            plan = resolved.plans[name]
            provider = registry.provider(plan.descriptor.id)
            expected[plan.descriptor.id] = {
                "descriptor": plan.descriptor.model_dump(mode="json"),
                "source": hashlib.sha256(Path(inspect.getfile(type(provider))).read_bytes()).hexdigest(),
            }
            for field in requirements:
                requirements[field].update(plan.metadata.get("runtime_requirements", {}).get(field, []))
        requirements = {name: sorted(values) for name, values in requirements.items()}
        if deployment.backend == "docker":
            distributions = {"roborsi", "roborsi-sdk", *(origins[name] for name in expected)}
            host_files = {}
            for name in distributions:
                dist = metadata.distribution(name)
                host_files[name] = {"version": dist.version, "files": {
                    str(item): hashlib.sha256(Path(dist.locate_file(item)).read_bytes()).hexdigest()
                    for item in dist.files or () if str(item).startswith(("roborsi/", "robots/", "benchmarks/"))
                    and not str(item).endswith((".pyc", ".pyo"))
                }}
            container = "roborsi-qualify-" + uuid.uuid4().hex[:12]
            command = ["docker", "run", "--name", container, "--rm", "--network", "none", "--read-only", "--tmpfs", "/tmp", "--entrypoint", "python3"]
            for mount in deployment.mounts:
                command += ["--mount", f"type=bind,source={Path(mount.source).resolve()},target={mount.target}" + (",readonly" if mount.readonly else "")]
            for name, value in deployment.environment.items():
                command += ["--env", name + "=" + value]
            command += [deployment.image, "-I", "-B", "-c", PROBE, json.dumps({"components": sorted(expected), "native": requirements, "distributions": sorted(distributions)})]
            try:
                response = subprocess.run(command, check=True, capture_output=True, text=True, timeout=120)
            finally:
                subprocess.run(["docker", "rm", "--force", container], capture_output=True, timeout=30)
            probe = json.loads(response.stdout)
            if probe["core"] != core_identity() or probe["plugins"] != expected or probe["distribution_files"] != host_files:
                raise ValueError(f"{role}: runtime image core/provider implementation differs")
            if not all(probe["modules"].values()) or not all(probe["assets"].values()) or not all(probe["provenance"].values()):
                raise ValueError(f"{role}: runtime image is missing declared native modules, assets or provenance")
            result[role] = {"backend": "docker", **{key: probe[key] for key in ("modules", "assets", "provenance", "distributions")}}
        else:
            modules = {}
            for name in requirements["modules"]:
                selected = importlib.util.find_spec(name)
                if not selected or not selected.origin:
                    raise ValueError(f"{role}: missing native module {name}; supply a complete wheel closure or pinned runtime image")
                path = Path(selected.origin).resolve()
                if not path.is_relative_to(site) or path.relative_to(site).as_posix() not in owners:
                    raise ValueError(f"{role}: native module is outside the locked wheel closure: {name}")
                modules[name] = True
            for name in requirements["asset_env"]:
                value = deployment.environment.get(name)
                if not value or not Path(value).is_dir() or not any(Path(value).resolve().is_relative_to(root) for root in asset_roots):
                    raise ValueError(f"{role}: declare native data in deployment.environment and --asset: {name}")
            provenance = {name: deployment.environment.get(name) for name in requirements["provenance_env"]}
            if not all(provenance.values()):
                raise ValueError(f"{role}: native source/data provenance is missing")
            result[role] = {"backend": "local", "modules": modules, "assets": requirements["asset_env"], "provenance": provenance}
    return result
