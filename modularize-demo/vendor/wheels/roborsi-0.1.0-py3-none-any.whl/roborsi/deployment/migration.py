"""Explicit migration from source-based M3/M4 presets to installed providers."""

from __future__ import annotations

import hashlib
import json
from importlib.metadata import distribution
from pathlib import Path

from roborsi.assembly.spec import AssemblySpec

PRESETS = {"sensenova_roborsi_27b_no_tools", "sensenova_roborsi_27b_vla_sam3"}


def migrate_legacy_assembly(spec, root):
    """Keep business settings; refuse to replace a customized preset silently.

Assembly/RunSpec v1 and component/episode v1 remain wire compatible. Content
locks intentionally need regeneration when upgrading the pre-M5 monolith.
"""
    document, changes = spec.model_dump(mode="json"), []
    for alias, node in document["components"].items():
        if node["component"] != "agent.roborsi_27b" or "config_path" not in node["config"]:
            continue
        from roborsi.agents.config import AgentConfig

        config = node["config"]
        source = (Path(root) / config["config_path"]).resolve()
        if source.stem not in PRESETS:
            raise ValueError("custom Agent presets require explicit migration; no settings were dropped")
        target = Path(distribution("roborsi-agent-27b").locate_file(
            "roborsi/integrations/presets/" + source.name
        ))
        left = AgentConfig.from_file(source, overrides=config.get("overrides", []))
        right = AgentConfig.from_file(target, overrides=config.get("overrides", []))
        if left.document != right.document:
            raise ValueError("source preset differs from the installed preset; review custom settings explicitly")
        # Verify published preset layers/maps, not just their effective settings.
        def preset_inventory(loaded):
            return {p.relative_to(loaded.path.parent).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in loaded.input_files if p.is_relative_to(loaded.path.parent)}

        if preset_inventory(left) != preset_inventory(right):
            raise ValueError("source preset layers/resources differ from the published package")

        def inventory(loaded):
            return {p.relative_to(loaded.source_root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in loaded.input_files if p.suffix == ".py" and "robots" in p.relative_to(loaded.source_root).parts}

        if inventory(left) != inventory(right):
            raise ValueError("source policy code differs from the installed distribution")
        del config["config_path"]
        config["preset"] = source.stem
        changes.append({"component": alias, "source": source.name, "preset": source.stem})
    result = AssemblySpec.model_validate_json(json.dumps(document))
    return result, {"from": "source-assembly/v1", "to": "installed-assembly/v1", "changes": changes,
                    "locks": "regenerate; never rewrite or accept an old content lock implicitly"}
