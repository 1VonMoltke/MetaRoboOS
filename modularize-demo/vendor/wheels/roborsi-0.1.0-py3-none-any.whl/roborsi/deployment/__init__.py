"""Versioned, offline-installable assembly deployment artifacts."""

DEPLOYMENT_API = "roborsi.deployment/v1"
