from roborsi.deployment.cli import main

raise SystemExit(main())
