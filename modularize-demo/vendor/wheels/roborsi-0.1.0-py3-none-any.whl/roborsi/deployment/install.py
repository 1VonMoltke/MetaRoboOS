#!/usr/bin/env python3
"""Standalone stdlib bootstrap: verify, create a fresh venv, install offline.

Copy of this file travels inside each deployment artifact. It needs only the
declared Python and its standard venv/ensurepip modules, never an installed core.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import subprocess
import venv
from pathlib import Path, PurePosixPath


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def verify(directory):
    manifest = directory / "deployment.json"
    if manifest.is_symlink():
        raise ValueError("linked deployment manifest")
    document = json.loads(manifest.read_text())
    if document.get("schema_version") != 1 or document.get("api") != "roborsi.deployment/v1":
        raise ValueError("unsupported deployment schema; explicit migration required")
    content = {key: value for key, value in document.items() if key != "fingerprint"}
    actual = hashlib.sha256(json.dumps(content, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    if document.get("fingerprint") != actual:
        raise ValueError("deployment manifest identity differs")
    inventory = set()
    for path in directory.rglob("*"):
        if path.is_symlink():
            raise ValueError("linked deployment member")
        if path.is_file() and path != manifest:
            inventory.add(path.relative_to(directory).as_posix())
    if inventory != set(document["files"]):
        raise ValueError("deployment file inventory differs")
    for name, expected in document["files"].items():
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts or "\\" in name or path.as_posix() != name:
            raise ValueError("invalid deployment member path")
        if digest(directory / name) != expected:
            raise ValueError(f"deployment content differs: {name}")
    current = {"implementation": platform.python_implementation(), "version": ".".join(platform.python_version_tuple()[:2]),
               "system": platform.system(), "machine": platform.machine()}
    if document["python"] != current:
        raise ValueError("deployment Python/platform differs; re-export for this target")
    return document


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--load-images", action="store_true")
    parser.add_argument("--expect-fingerprint")
    args = parser.parse_args(argv)
    directory, target = args.bundle.resolve(), args.target.absolute()
    document = verify(directory)
    if args.expect_fingerprint and args.expect_fingerprint != document["fingerprint"]:
        raise ValueError("deployment differs from --expect-fingerprint")
    if target.exists():
        raise FileExistsError("installation target exists; refusing to merge environments")
    if target.is_relative_to(directory):
        raise ValueError("install the environment outside the immutable artifact")
    # No parent pip settings, user sites, shared caches or injected Python paths.
    environment = {key: value for key, value in os.environ.items()
                   if key in {"PATH", "HOME", "TMPDIR", "TEMP", "TMP", "LANG", "LC_ALL", "SYSTEMROOT"}}
    environment.update(PIP_CONFIG_FILE=os.devnull, PIP_NO_INDEX="1", PIP_NO_CACHE_DIR="1",
                       PIP_DISABLE_PIP_VERSION_CHECK="1", PYTHONNOUSERSITE="1")
    target.mkdir(parents=True, exist_ok=False)
    venv.EnvBuilder(with_pip=True, system_site_packages=False).create(target)
    python = target / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    subprocess.run([
        str(python), "-I", "-B", "-m", "pip", "--isolated", "install", "--no-index", "--no-cache-dir",
        "--require-hashes", "--find-links", str(directory / "wheels"),
        "-r", str(directory / "requirements.lock"),
    ], cwd=target, env=environment, check=True)
    subprocess.run([str(python), "-I", "-B", "-m", "pip", "check"], cwd=target, env=environment, check=True)
    subprocess.run([str(python), "-I", "-B", "-m", "roborsi.deployment", "verify",
                    "--bundle", str(directory), "--installed"], cwd=target, env=environment, check=True)
    if args.load_images:
        for image in document["images"]:
            if not image["archive"]:
                raise ValueError("deployment contains an image reference without its archive")
            subprocess.run(["docker", "load", "-i", str(directory / image["archive"])], check=True)
    print(json.dumps({"fingerprint": document["fingerprint"], "python": str(python)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
