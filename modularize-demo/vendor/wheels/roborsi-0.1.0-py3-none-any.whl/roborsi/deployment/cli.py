"""Export, verify, import and run independently installable assembly artifacts."""

from __future__ import annotations

import argparse
import json
import signal
import subprocess
import sys
from pathlib import Path
from threading import Event

from roborsi.assembly.spec import AssemblySpec, RunSpec, load_spec
from roborsi.deployment.artifact import (
    export_artifact,
    installed_wheels,
    materialize,
    runtime_prerequisites,
    verify_artifact,
)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    migrate = commands.add_parser("migrate")
    migrate.add_argument("--assembly", type=Path, required=True)
    migrate.add_argument("--root", type=Path, default=Path.cwd())
    migrate.add_argument("--output", type=Path, required=True)
    export = commands.add_parser("export")
    export.add_argument("--assembly", type=Path, required=True)
    export.add_argument("--run-spec", type=Path, required=True)
    export.add_argument("--root", type=Path, default=Path.cwd())
    export.add_argument("--wheelhouse", type=Path, required=True)
    export.add_argument("--output", type=Path, required=True)
    export.add_argument("--require", action="append", default=[])
    export.add_argument("--asset", action="append", default=[], metavar="NAME=PATH")
    export.add_argument("--image-references-only", action="store_true",
                        help="explicitly require pre-provisioned pinned images rather than archive them")
    verify = commands.add_parser("verify")
    verify.add_argument("--bundle", type=Path, required=True)
    verify.add_argument("--installed", action="store_true")
    verify.add_argument("--runtime", action="store_true")
    verify.add_argument("--expect-fingerprint")
    install = commands.add_parser("import")
    install.add_argument("--bundle", type=Path, required=True)
    install.add_argument("--target", type=Path, required=True)
    install.add_argument("--load-images", action="store_true")
    install.add_argument("--expect-fingerprint")
    run = commands.add_parser("run")
    run.add_argument("--bundle", type=Path, required=True)
    run.add_argument("--workspace", type=Path, required=True)
    run.add_argument("--expect-fingerprint")
    try:
        args = parser.parse_args(argv)
        if args.command == "migrate":
            from roborsi.deployment.migration import migrate_legacy_assembly

            migrated, report = migrate_legacy_assembly(load_spec(args.assembly, AssemblySpec), args.root)
            with args.output.open("x") as stream:
                stream.write(migrated.model_dump_json(indent=2) + "\n")
            print(json.dumps(report, indent=2))
            return 0
        if args.command == "export":
            assets = {}
            for item in args.asset:
                name, separator, path = item.partition("=")
                if not separator or name in assets:
                    raise ValueError("assets must have unique NAME=PATH declarations")
                assets[name] = path
            document = export_artifact(
                load_spec(args.assembly, AssemblySpec), load_spec(args.run_spec, RunSpec),
                root=args.root, wheelhouse=args.wheelhouse, output=args.output,
                requirements=args.require, assets=assets, archive_images=not args.image_references_only,
            )
        elif args.command == "verify":
            document = (runtime_prerequisites(args.bundle) if args.runtime else
                        installed_wheels(args.bundle) if args.installed else verify_artifact(args.bundle))
        elif args.command == "import":
            from roborsi.deployment.install import main as bootstrap

            return bootstrap(["--bundle", str(args.bundle), "--target", str(args.target)] +
                             (["--load-images"] if args.load_images else []) +
                             (["--expect-fingerprint", args.expect_fingerprint] if args.expect_fingerprint else []))
        else:
            from roborsi.evaluation.component_workflow import run_assembly

            document = runtime_prerequisites(args.bundle)
            if args.expect_fingerprint and args.expect_fingerprint != document["fingerprint"]:
                raise ValueError("deployment differs from --expect-fingerprint")
            resolved, settings = materialize(args.bundle, args.workspace)
            cancel, previous = Event(), {}
            for signum in (signal.SIGTERM, signal.SIGINT):
                previous[signum] = signal.signal(signum, lambda *args: cancel.set())
            try:
                report = run_assembly(resolved.spec, settings, root=resolved.root, expected_lock=resolved.lock, cancel_event=cancel)
            finally:
                for signum, handler in previous.items():
                    signal.signal(signum, handler)
            print(json.dumps({"deployment": document["fingerprint"], "report": report.as_dict()}, indent=2))
            return 0 if all(c.result.status in {"success", "task_failure"} for c in report.cases) else 1
        if getattr(args, "expect_fingerprint", None) and args.expect_fingerprint != document["fingerprint"]:
            raise ValueError("deployment differs from --expect-fingerprint")
        print(json.dumps({"fingerprint": document["fingerprint"], "assembly_fingerprint": document["assembly_fingerprint"],
                          "packages": sorted(document["packages"])}, indent=2))
        return 0
    except (ValueError, OSError, ImportError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f"deployment: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
