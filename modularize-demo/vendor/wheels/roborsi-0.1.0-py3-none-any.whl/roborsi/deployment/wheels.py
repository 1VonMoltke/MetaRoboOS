"""Resolve a complete, platform-compatible dependency closure from wheel bytes."""

from __future__ import annotations

import hashlib
import sys
import zipfile
from dataclasses import dataclass
from email.parser import BytesParser
from importlib import metadata
from pathlib import Path, PurePosixPath

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name, parse_wheel_filename


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass
class Wheel:
    path: Path
    name: str
    version: str
    requirements: tuple
    extras: set
    digest: str


def read_wheel(path):
    name, version, _, tags = parse_wheel_filename(path.name)
    if not tags.intersection(sys_tags()):
        raise ValueError(f"incompatible wheel platform: {path.name}")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError(f"duplicate wheel entries: {path.name}")
        for item in archive.infolist():
            member = PurePosixPath(item.filename)
            if member.is_absolute() or ".." in member.parts or "\\" in item.filename:
                raise ValueError(f"invalid wheel path: {item.filename}")
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError(f"linked wheel entry: {item.filename}")
        records = [n for n in names if n.endswith(".dist-info/METADATA")]
        if len(records) != 1:
            raise ValueError(f"wheel needs one METADATA: {path.name}")
        document = BytesParser().parsebytes(archive.read(records[0]))
    if canonicalize_name(document["Name"]) != name or document["Version"] != str(version):
        raise ValueError(f"wheel filename/metadata mismatch: {path.name}")
    if document["Requires-Python"] and not SpecifierSet(document["Requires-Python"]).contains(
        ".".join(map(str, sys.version_info[:3])), prereleases=True
    ):
        raise ValueError(f"unsupported Python for {name}")
    return Wheel(path, name, str(version), tuple(document.get_all("Requires-Dist", [])),
                 set(document.get_all("Provides-Extra", [])), sha256(path))


def dependency_closure(wheelhouse, requirements):
    available = {}
    for path in sorted(Path(wheelhouse).glob("*.whl")):
        wheel = read_wheel(path)
        if wheel.name in available:
            raise ValueError(f"ambiguous wheel versions: {wheel.name}")
        available[wheel.name] = wheel
    selected, extras, processed = {}, {}, {}
    pending = [Requirement(value) for value in requirements]
    while pending:
        requirement = pending.pop()
        name = canonicalize_name(requirement.name)
        if requirement.url:
            raise ValueError("deployment dependencies must use versioned wheel artifacts")
        if name not in available:
            raise ValueError(f"missing dependency wheel: {requirement}")
        wheel = available[name]
        if not requirement.specifier.contains(wheel.version, prereleases=True):
            raise ValueError(f"incompatible dependency: {requirement}; wheel={wheel.version}")
        selected[name] = wheel
        extras.setdefault(name, set()).update(requirement.extras)
        if extras[name] - wheel.extras:
            raise ValueError(f"unknown extras for {name}: {sorted(extras[name] - wheel.extras)}")
        state = frozenset(extras[name])
        if processed.get(name) == state:
            continue
        processed[name] = state
        for raw in wheel.requirements:
            dependency = Requirement(raw)
            if dependency.marker is None or any(
                dependency.marker.evaluate({**default_environment(), "extra": extra})
                for extra in {"", *state}
            ):
                pending.append(dependency)
    return selected


def verify_installed(wheels):
    """Check actual site files, not only package names or installed versions."""
    owners = {}
    for name, wheel in wheels.items():
        installed = metadata.distribution(name)
        if installed.version != wheel.version:
            raise ValueError(f"installed dependency version differs: {name}")
        for item in installed.files or ():
            if str(item).endswith(".pth"):
                raise ValueError(f"editable/path-injected dependency cannot be exported: {name}")
        with zipfile.ZipFile(wheel.path) as archive:
            for item in archive.infolist():
                member = item.filename
                if member.endswith("/") or ".data/" in member or member.endswith(".dist-info/RECORD"):
                    continue
                location = Path(installed.locate_file(member))
                if not location.is_file() or location.is_symlink() or hashlib.sha256(
                    location.read_bytes()
                ).digest() != hashlib.sha256(archive.read(item)).digest():
                    raise ValueError(f"installed wheel content differs: {name}:{member}")
                if member in owners:
                    raise ValueError(f"overlapping distribution ownership: {member}")
                owners[member] = name
    return owners
